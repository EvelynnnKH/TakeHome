﻿namespace Week_02_TakeHome_Wordle_KW
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.btn_MulaiPermainan = new System.Windows.Forms.Button();
            this.tBox_WordKelima = new System.Windows.Forms.TextBox();
            this.label_WordKelima = new System.Windows.Forms.Label();
            this.tBox_WordKeempat = new System.Windows.Forms.TextBox();
            this.label_WordKeempat = new System.Windows.Forms.Label();
            this.tBox_WordKetiga = new System.Windows.Forms.TextBox();
            this.label_WordKetiga = new System.Windows.Forms.Label();
            this.tBox_WordKedua = new System.Windows.Forms.TextBox();
            this.label_WordKedua = new System.Windows.Forms.Label();
            this.tBox_WordPertama = new System.Windows.Forms.TextBox();
            this.label_WordPertama = new System.Windows.Forms.Label();
            this.pBox_BiarLucuAja = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_BiarLucuAja)).BeginInit();
            this.SuspendLayout();
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // btn_MulaiPermainan
            // 
            this.btn_MulaiPermainan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_MulaiPermainan.Location = new System.Drawing.Point(167, 302);
            this.btn_MulaiPermainan.Name = "btn_MulaiPermainan";
            this.btn_MulaiPermainan.Size = new System.Drawing.Size(100, 23);
            this.btn_MulaiPermainan.TabIndex = 23;
            this.btn_MulaiPermainan.Text = "Start";
            this.btn_MulaiPermainan.UseVisualStyleBackColor = true;
            this.btn_MulaiPermainan.Click += new System.EventHandler(this.btn_MulaiPermainan_Click);
            // 
            // tBox_WordKelima
            // 
            this.tBox_WordKelima.Location = new System.Drawing.Point(167, 255);
            this.tBox_WordKelima.Name = "tBox_WordKelima";
            this.tBox_WordKelima.Size = new System.Drawing.Size(100, 22);
            this.tBox_WordKelima.TabIndex = 22;
            // 
            // label_WordKelima
            // 
            this.label_WordKelima.AutoSize = true;
            this.label_WordKelima.Location = new System.Drawing.Point(100, 258);
            this.label_WordKelima.Name = "label_WordKelima";
            this.label_WordKelima.Size = new System.Drawing.Size(50, 16);
            this.label_WordKelima.TabIndex = 21;
            this.label_WordKelima.Text = "Word 5";
            // 
            // tBox_WordKeempat
            // 
            this.tBox_WordKeempat.Location = new System.Drawing.Point(167, 214);
            this.tBox_WordKeempat.Name = "tBox_WordKeempat";
            this.tBox_WordKeempat.Size = new System.Drawing.Size(100, 22);
            this.tBox_WordKeempat.TabIndex = 20;
            // 
            // label_WordKeempat
            // 
            this.label_WordKeempat.AutoSize = true;
            this.label_WordKeempat.Location = new System.Drawing.Point(100, 217);
            this.label_WordKeempat.Name = "label_WordKeempat";
            this.label_WordKeempat.Size = new System.Drawing.Size(50, 16);
            this.label_WordKeempat.TabIndex = 19;
            this.label_WordKeempat.Text = "Word 4";
            // 
            // tBox_WordKetiga
            // 
            this.tBox_WordKetiga.Location = new System.Drawing.Point(167, 175);
            this.tBox_WordKetiga.Name = "tBox_WordKetiga";
            this.tBox_WordKetiga.Size = new System.Drawing.Size(100, 22);
            this.tBox_WordKetiga.TabIndex = 18;
            // 
            // label_WordKetiga
            // 
            this.label_WordKetiga.AutoSize = true;
            this.label_WordKetiga.Location = new System.Drawing.Point(100, 178);
            this.label_WordKetiga.Name = "label_WordKetiga";
            this.label_WordKetiga.Size = new System.Drawing.Size(50, 16);
            this.label_WordKetiga.TabIndex = 17;
            this.label_WordKetiga.Text = "Word 3";
            // 
            // tBox_WordKedua
            // 
            this.tBox_WordKedua.Location = new System.Drawing.Point(167, 134);
            this.tBox_WordKedua.Name = "tBox_WordKedua";
            this.tBox_WordKedua.Size = new System.Drawing.Size(100, 22);
            this.tBox_WordKedua.TabIndex = 16;
            // 
            // label_WordKedua
            // 
            this.label_WordKedua.AutoSize = true;
            this.label_WordKedua.Location = new System.Drawing.Point(100, 137);
            this.label_WordKedua.Name = "label_WordKedua";
            this.label_WordKedua.Size = new System.Drawing.Size(50, 16);
            this.label_WordKedua.TabIndex = 15;
            this.label_WordKedua.Text = "Word 2";
            // 
            // tBox_WordPertama
            // 
            this.tBox_WordPertama.Location = new System.Drawing.Point(167, 93);
            this.tBox_WordPertama.Name = "tBox_WordPertama";
            this.tBox_WordPertama.Size = new System.Drawing.Size(100, 22);
            this.tBox_WordPertama.TabIndex = 14;
            // 
            // label_WordPertama
            // 
            this.label_WordPertama.AutoSize = true;
            this.label_WordPertama.Location = new System.Drawing.Point(100, 96);
            this.label_WordPertama.Name = "label_WordPertama";
            this.label_WordPertama.Size = new System.Drawing.Size(50, 16);
            this.label_WordPertama.TabIndex = 13;
            this.label_WordPertama.Text = "Word 1";
            // 
            // pBox_BiarLucuAja
            // 
            this.pBox_BiarLucuAja.BackColor = System.Drawing.Color.Azure;
            this.pBox_BiarLucuAja.Location = new System.Drawing.Point(72, 61);
            this.pBox_BiarLucuAja.Name = "pBox_BiarLucuAja";
            this.pBox_BiarLucuAja.Size = new System.Drawing.Size(240, 303);
            this.pBox_BiarLucuAja.TabIndex = 12;
            this.pBox_BiarLucuAja.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_MulaiPermainan);
            this.Controls.Add(this.tBox_WordKelima);
            this.Controls.Add(this.label_WordKelima);
            this.Controls.Add(this.tBox_WordKeempat);
            this.Controls.Add(this.label_WordKeempat);
            this.Controls.Add(this.tBox_WordKetiga);
            this.Controls.Add(this.label_WordKetiga);
            this.Controls.Add(this.tBox_WordKedua);
            this.Controls.Add(this.label_WordKedua);
            this.Controls.Add(this.tBox_WordPertama);
            this.Controls.Add(this.label_WordPertama);
            this.Controls.Add(this.pBox_BiarLucuAja);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_BiarLucuAja)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Button btn_MulaiPermainan;
        private System.Windows.Forms.TextBox tBox_WordKelima;
        private System.Windows.Forms.Label label_WordKelima;
        private System.Windows.Forms.TextBox tBox_WordKeempat;
        private System.Windows.Forms.Label label_WordKeempat;
        private System.Windows.Forms.TextBox tBox_WordKetiga;
        private System.Windows.Forms.Label label_WordKetiga;
        private System.Windows.Forms.TextBox tBox_WordKedua;
        private System.Windows.Forms.Label label_WordKedua;
        private System.Windows.Forms.TextBox tBox_WordPertama;
        private System.Windows.Forms.Label label_WordPertama;
        private System.Windows.Forms.PictureBox pBox_BiarLucuAja;
    }
}

