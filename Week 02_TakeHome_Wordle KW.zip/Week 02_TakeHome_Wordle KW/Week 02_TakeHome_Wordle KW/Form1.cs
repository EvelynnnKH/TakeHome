﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_02_TakeHome_Wordle_KW
{
    public partial class Form1 : Form
    {
        public string uppercasedChoosenWord;
        public Form1()
        {
            InitializeComponent();      
        }
        private void btn_MulaiPermainan_Click(object sender, EventArgs e)
        {
            string[] listOfWords = new string[5]; 
            listOfWords[0] = (tBox_WordPertama.Text);
            listOfWords[1] = (tBox_WordKedua.Text);
            listOfWords[2] = (tBox_WordKetiga.Text);
            listOfWords[3] = (tBox_WordKeempat.Text);
            listOfWords[4] = (tBox_WordKelima.Text);
            if (PengecekanValidTidak(tBox_WordPertama.ToString(), listOfWords) == true && PengecekanValidTidak(tBox_WordKedua.ToString(), listOfWords) == true && PengecekanValidTidak(tBox_WordKetiga.ToString(), listOfWords) == true && PengecekanValidTidak(tBox_WordKeempat.ToString(), listOfWords) == true && PengecekanValidTidak(tBox_WordKelima.ToString(), listOfWords) == true)
            {
                Random rnd = new Random();
                int pilihanKata = rnd.Next(5);
                uppercasedChoosenWord = listOfWords[pilihanKata];


                Hide();
                Interface_Game InterfaceGame = new Interface_Game(uppercasedChoosenWord);
                InterfaceGame.ShowDialog();
                Show();
            }
            else
            {
                MessageBox.Show("Input Invalid");
            }
        }
        private static bool PengecekanValidTidak(string KataYangMauDicek, string[] listOfWords)
        {
            string kataSekarang = KataYangMauDicek.Substring(36);
            int indexWordSekarang = Array.IndexOf(listOfWords, kataSekarang);
            int[] angkaNgecek = {0,1,2,3,4};
            angkaNgecek = angkaNgecek.Except(new int[] { indexWordSekarang }).ToArray();
            for (int i = 0; i < 4; i++)
            {
                if (listOfWords[indexWordSekarang] == listOfWords[angkaNgecek[i]])
                {
                    return false;
                }
            }
            if (KataYangMauDicek.Length != 41)
            {
                return false;
            }
            return true;
        }
    }
}
