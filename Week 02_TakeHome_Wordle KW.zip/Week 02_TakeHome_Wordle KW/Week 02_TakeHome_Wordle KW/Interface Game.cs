﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_02_TakeHome_Wordle_KW
{
    public partial class Interface_Game : Form
    {
        public string hurufSekarang;
        string[]jawaban = new string[5];
        public Interface_Game(string kataTerpilih)
        {
            InitializeComponent();
            Form1 interface_Game = new Form1();
            string uppercasedChoosenWord = kataTerpilih.ToUpper();
            label_KataYangTerpilih.Text = uppercasedChoosenWord;


           jawaban = new string[] { uppercasedChoosenWord.Substring(0, 1), uppercasedChoosenWord.Substring(1, 1), uppercasedChoosenWord.Substring(2, 1), uppercasedChoosenWord.Substring(3, 1), uppercasedChoosenWord.Substring(4, 1) };
            label_HurufPertama.Text =jawaban[0];
            label_HurufKedua.Text =jawaban[1];
            label_HurufKetiga.Text =jawaban[2];
            label_HurufKeempat.Text =jawaban[3];
            label_HurufKelima.Text =jawaban[4];
        }
        
        private void ListIndexHurufYangBenar(string huruf)
        {
            List<int> posisiHurufYangTertebak = new List<int>();
            for (int i = 0; i <jawaban.Length; i++)
            {
                if (huruf == jawaban[i])
                {
                    posisiHurufYangTertebak.Add(i);
                }
            }
            MunculinYangBenar(posisiHurufYangTertebak);
        }

        private void MunculinYangBenar(List<int> posisiHurufYangTertebak)
        {
            for (int i = 0; i < posisiHurufYangTertebak.Count; i++)
            {
                if (posisiHurufYangTertebak[i] == 0)
                {
                    label_HurufPertama.Visible = true;
                }
                if (posisiHurufYangTertebak[i] == 1)
                {
                    label_HurufKedua.Visible = true;
                }
                if (posisiHurufYangTertebak[i] == 2)
                {
                    label_HurufKetiga.Visible = true;
                }
                if (posisiHurufYangTertebak[i] == 3)
                {
                    label_HurufKeempat.Visible = true;
                }
                if (posisiHurufYangTertebak[i] == 4)
                {
                    label_HurufKelima.Visible = true;
                }
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("Q");
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("W");
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("E");
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("R");
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("T");
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("Y");
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("U");
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("I");
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("O");
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("P");
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("A");
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("S");
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("D");
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("F");
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("G");
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("H");
        }
        private void btn_J_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("J");
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("K");
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("L")    ;
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("Z");
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("X");
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("C");
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("V");
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("B");
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("N");
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            ListIndexHurufYangBenar("M");
        }
    }
}
