﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    internal class Data_Applicationcs
    {
        public static List<Rekening> daftarRekening = new List<Rekening>();
        public static int foundRekeningIndex;
        public static bool UsernameAlreadyregistered(string userNameUser)
        {
            for (int i = 0; i < Data_Applicationcs.daftarRekening.Count; i++)
            {
                if (Data_Applicationcs.daftarRekening[i].rekeningName == userNameUser)
                {
                    return true;
                }
            }
            return false;
        }
        public static int GetRekeningByUserPass(string password, string username)
        {
            for (int i = 0; i < Data_Applicationcs.daftarRekening.Count; i++)
            {
                if (Data_Applicationcs.daftarRekening[i].passwordAccount == password && Data_Applicationcs.daftarRekening[i].rekeningName == username)
                {
                    return i;
                }
            }
            return -1;
        }

    }
}
