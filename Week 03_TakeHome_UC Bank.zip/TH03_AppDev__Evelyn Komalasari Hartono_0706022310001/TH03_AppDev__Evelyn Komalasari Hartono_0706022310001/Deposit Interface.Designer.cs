﻿namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    partial class Deposit_Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_AddDeposit = new System.Windows.Forms.Button();
            this.label_InputAmount = new System.Windows.Forms.Label();
            this.label_UCBank = new System.Windows.Forms.Label();
            this.tBox_DepositAmount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.BackColor = System.Drawing.Color.White;
            this.btn_LogOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_LogOut.Location = new System.Drawing.Point(210, 105);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(75, 23);
            this.btn_LogOut.TabIndex = 14;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = false;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_AddDeposit
            // 
            this.btn_AddDeposit.BackColor = System.Drawing.Color.White;
            this.btn_AddDeposit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_AddDeposit.Location = new System.Drawing.Point(128, 236);
            this.btn_AddDeposit.Name = "btn_AddDeposit";
            this.btn_AddDeposit.Size = new System.Drawing.Size(83, 23);
            this.btn_AddDeposit.TabIndex = 13;
            this.btn_AddDeposit.Text = "Deposit";
            this.btn_AddDeposit.UseVisualStyleBackColor = false;
            this.btn_AddDeposit.Click += new System.EventHandler(this.btn_AddDeposit_Click);
            // 
            // label_InputAmount
            // 
            this.label_InputAmount.AutoSize = true;
            this.label_InputAmount.Location = new System.Drawing.Point(105, 157);
            this.label_InputAmount.Name = "label_InputAmount";
            this.label_InputAmount.Size = new System.Drawing.Size(133, 16);
            this.label_InputAmount.TabIndex = 12;
            this.label_InputAmount.Text = "Input Deposit Amount";
            // 
            // label_UCBank
            // 
            this.label_UCBank.AutoSize = true;
            this.label_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UCBank.Location = new System.Drawing.Point(102, 59);
            this.label_UCBank.Name = "label_UCBank";
            this.label_UCBank.Size = new System.Drawing.Size(133, 32);
            this.label_UCBank.TabIndex = 11;
            this.label_UCBank.Text = "UC Bank";
            // 
            // tBox_DepositAmount
            // 
            this.tBox_DepositAmount.Location = new System.Drawing.Point(108, 186);
            this.tBox_DepositAmount.Name = "tBox_DepositAmount";
            this.tBox_DepositAmount.Size = new System.Drawing.Size(130, 22);
            this.tBox_DepositAmount.TabIndex = 15;
            // 
            // Deposit_Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tBox_DepositAmount);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.btn_AddDeposit);
            this.Controls.Add(this.label_InputAmount);
            this.Controls.Add(this.label_UCBank);
            this.Name = "Deposit_Interface";
            this.Text = "Deposit_Interface";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_AddDeposit;
        private System.Windows.Forms.Label label_InputAmount;
        private System.Windows.Forms.Label label_UCBank;
        private System.Windows.Forms.TextBox tBox_DepositAmount;
    }
}