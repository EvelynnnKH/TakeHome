﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    public partial class Deposit_Interface : Form
    {
        public Deposit_Interface()
        {
            InitializeComponent();
        }

        private void btn_AddDeposit_Click(object sender, EventArgs e)
        {
            if (Convert.ToDouble(tBox_DepositAmount.Text) > 0)
            {
                Data_Applicationcs.daftarRekening[Data_Applicationcs.foundRekeningIndex].Deposit(Convert.ToDouble(tBox_DepositAmount.Text));
                MessageBox.Show("Successfully Add Deposit");
                Interface_Rekening Rekening_Interface = new Interface_Rekening();
                Rekening_Interface.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            Form1 MainPage = new Form1();
            MainPage.Show();
            this.Hide();
        }
    }
}
