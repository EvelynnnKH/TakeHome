﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            int foundRekeningIndex = Data_Applicationcs.GetRekeningByUserPass(tBox_Password.Text, tBox_Username.Text);
            if (foundRekeningIndex > -1)
            {
                Data_Applicationcs.foundRekeningIndex = foundRekeningIndex;
                MessageBox.Show("Login Successful");
                Interface_Rekening Rekening_Interface = new Interface_Rekening();
                Rekening_Interface.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Account not registered");
            }
        }
        private void btn_Register_Click(object sender, EventArgs e)
        {
            Registration_Interface Registration_Interface = new Registration_Interface();
            Registration_Interface.Show();
            this.Hide();
        }
    }
}
