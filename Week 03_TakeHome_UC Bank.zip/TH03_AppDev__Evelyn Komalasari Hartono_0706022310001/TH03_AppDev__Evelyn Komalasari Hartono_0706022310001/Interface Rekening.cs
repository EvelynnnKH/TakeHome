﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    public partial class Interface_Rekening : Form
    {
        public Interface_Rekening()
        {
            InitializeComponent();
            Rekening selectedRekening = Data_Applicationcs.daftarRekening[Data_Applicationcs.foundRekeningIndex];
            label_Balance.Text = selectedRekening.BalanceInRupiah();
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            Deposit_Interface Deposit_Interface = new Deposit_Interface();
            Deposit_Interface.Show();
            this.Hide();
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            if (Data_Applicationcs.daftarRekening[Data_Applicationcs.foundRekeningIndex].balance <= 0)
            {
                MessageBox.Show("Balance is empty");
            }
            else
            {
                Withdraw_Interface Withdraw_Interface = new Withdraw_Interface();
                Withdraw_Interface.Show();
                this.Hide();
            }         
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            Form1 MainPage = new Form1();
            MainPage.Show();
            this.Hide();
        }
    }
}
