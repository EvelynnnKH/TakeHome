﻿namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    partial class Registration_Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_UCBank = new System.Windows.Forms.Label();
            this.label_UsernameRegistration = new System.Windows.Forms.Label();
            this.tBox_UsernameRegistration = new System.Windows.Forms.TextBox();
            this.tBox_PasswordRegistration = new System.Windows.Forms.TextBox();
            this.label_PasswordRegistration = new System.Windows.Forms.Label();
            this.btn_RegisterNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_UCBank
            // 
            this.label_UCBank.AutoSize = true;
            this.label_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UCBank.Location = new System.Drawing.Point(102, 59);
            this.label_UCBank.Name = "label_UCBank";
            this.label_UCBank.Size = new System.Drawing.Size(133, 32);
            this.label_UCBank.TabIndex = 1;
            this.label_UCBank.Text = "UC Bank";
            // 
            // label_UsernameRegistration
            // 
            this.label_UsernameRegistration.AutoSize = true;
            this.label_UsernameRegistration.Location = new System.Drawing.Point(82, 121);
            this.label_UsernameRegistration.Name = "label_UsernameRegistration";
            this.label_UsernameRegistration.Size = new System.Drawing.Size(73, 16);
            this.label_UsernameRegistration.TabIndex = 2;
            this.label_UsernameRegistration.Text = "Username:";
            // 
            // tBox_UsernameRegistration
            // 
            this.tBox_UsernameRegistration.Location = new System.Drawing.Point(154, 118);
            this.tBox_UsernameRegistration.Name = "tBox_UsernameRegistration";
            this.tBox_UsernameRegistration.Size = new System.Drawing.Size(100, 22);
            this.tBox_UsernameRegistration.TabIndex = 3;
            // 
            // tBox_PasswordRegistration
            // 
            this.tBox_PasswordRegistration.Location = new System.Drawing.Point(154, 155);
            this.tBox_PasswordRegistration.Name = "tBox_PasswordRegistration";
            this.tBox_PasswordRegistration.Size = new System.Drawing.Size(100, 22);
            this.tBox_PasswordRegistration.TabIndex = 5;
            // 
            // label_PasswordRegistration
            // 
            this.label_PasswordRegistration.AutoSize = true;
            this.label_PasswordRegistration.Location = new System.Drawing.Point(82, 158);
            this.label_PasswordRegistration.Name = "label_PasswordRegistration";
            this.label_PasswordRegistration.Size = new System.Drawing.Size(70, 16);
            this.label_PasswordRegistration.TabIndex = 4;
            this.label_PasswordRegistration.Text = "Password:";
            // 
            // btn_RegisterNew
            // 
            this.btn_RegisterNew.BackColor = System.Drawing.Color.White;
            this.btn_RegisterNew.Location = new System.Drawing.Point(131, 198);
            this.btn_RegisterNew.Name = "btn_RegisterNew";
            this.btn_RegisterNew.Size = new System.Drawing.Size(75, 23);
            this.btn_RegisterNew.TabIndex = 6;
            this.btn_RegisterNew.Text = "Register";
            this.btn_RegisterNew.UseVisualStyleBackColor = false;
            this.btn_RegisterNew.Click += new System.EventHandler(this.btn_RegisterNew_Click);
            // 
            // Registration_Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_RegisterNew);
            this.Controls.Add(this.tBox_PasswordRegistration);
            this.Controls.Add(this.label_PasswordRegistration);
            this.Controls.Add(this.tBox_UsernameRegistration);
            this.Controls.Add(this.label_UsernameRegistration);
            this.Controls.Add(this.label_UCBank);
            this.Name = "Registration_Interface";
            this.Text = "Registration_Interface";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_UCBank;
        private System.Windows.Forms.Label label_UsernameRegistration;
        private System.Windows.Forms.TextBox tBox_UsernameRegistration;
        private System.Windows.Forms.TextBox tBox_PasswordRegistration;
        private System.Windows.Forms.Label label_PasswordRegistration;
        private System.Windows.Forms.Button btn_RegisterNew;
    }
}