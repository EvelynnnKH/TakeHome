﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    public partial class Registration_Interface : Form
    {
        string userNameUser;
        string passwordUser;
        double balance;
        Rekening usersRekening;
        public Registration_Interface()
        {
            InitializeComponent();
        }
        private void btn_RegisterNew_Click(object sender, EventArgs e)
        {
            userNameUser = tBox_UsernameRegistration.Text;
            passwordUser = tBox_PasswordRegistration.Text;
            if (Data_Applicationcs.UsernameAlreadyregistered(userNameUser) == false)
            {
                usersRekening = new Rekening(userNameUser, passwordUser, balance);
                Data_Applicationcs.daftarRekening.Add(usersRekening);
                MessageBox.Show("Register successful");
                Form1 MainPage = new Form1();
                MainPage.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username has been used");
            }
        }
    }
}
