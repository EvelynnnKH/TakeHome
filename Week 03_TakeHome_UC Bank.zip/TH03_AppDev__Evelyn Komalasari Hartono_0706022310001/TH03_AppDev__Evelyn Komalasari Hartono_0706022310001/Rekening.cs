﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    internal class Rekening
    {
        public string rekeningName;
        public string passwordAccount;
        public double balance;
        public Rekening(string rekeningType, string password, double balance)
        {
            rekeningName = rekeningType;
            passwordAccount = password;
            this.balance = balance;
        }

        public void Deposit(double depositedBalance)
        {
            balance = balance + depositedBalance;
        }

        public void Withdraw(double withdrawedBalance)
        {
            balance = balance - withdrawedBalance;
        }

        public string BalanceInRupiah()
        {
            string balanceInRupiah = balance.ToString("C2", CultureInfo.CreateSpecificCulture("id-ID"));
            return balanceInRupiah;
        }

    }
}
