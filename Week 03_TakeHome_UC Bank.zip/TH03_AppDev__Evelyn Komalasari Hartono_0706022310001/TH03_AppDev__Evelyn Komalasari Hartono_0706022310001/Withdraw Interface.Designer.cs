﻿namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    partial class Withdraw_Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.label_UCBank = new System.Windows.Forms.Label();
            this.tBox_WithdrawAmount = new System.Windows.Forms.TextBox();
            this.btn_WithdrawMoney = new System.Windows.Forms.Button();
            this.label_InputWithdrawAmount = new System.Windows.Forms.Label();
            this.label_Balance = new System.Windows.Forms.Label();
            this.label_BalanceText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.BackColor = System.Drawing.Color.White;
            this.btn_LogOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_LogOut.Location = new System.Drawing.Point(210, 105);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(75, 23);
            this.btn_LogOut.TabIndex = 12;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = false;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // label_UCBank
            // 
            this.label_UCBank.AutoSize = true;
            this.label_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UCBank.Location = new System.Drawing.Point(102, 59);
            this.label_UCBank.Name = "label_UCBank";
            this.label_UCBank.Size = new System.Drawing.Size(133, 32);
            this.label_UCBank.TabIndex = 11;
            this.label_UCBank.Text = "UC Bank";
            // 
            // tBox_WithdrawAmount
            // 
            this.tBox_WithdrawAmount.Location = new System.Drawing.Point(105, 203);
            this.tBox_WithdrawAmount.Name = "tBox_WithdrawAmount";
            this.tBox_WithdrawAmount.Size = new System.Drawing.Size(130, 22);
            this.tBox_WithdrawAmount.TabIndex = 18;
            // 
            // btn_WithdrawMoney
            // 
            this.btn_WithdrawMoney.BackColor = System.Drawing.Color.White;
            this.btn_WithdrawMoney.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_WithdrawMoney.Location = new System.Drawing.Point(126, 236);
            this.btn_WithdrawMoney.Name = "btn_WithdrawMoney";
            this.btn_WithdrawMoney.Size = new System.Drawing.Size(85, 23);
            this.btn_WithdrawMoney.TabIndex = 17;
            this.btn_WithdrawMoney.Text = "Withdraw";
            this.btn_WithdrawMoney.UseVisualStyleBackColor = false;
            this.btn_WithdrawMoney.Click += new System.EventHandler(this.btn_WithdrawMoney_Click);
            // 
            // label_InputWithdrawAmount
            // 
            this.label_InputWithdrawAmount.AutoSize = true;
            this.label_InputWithdrawAmount.Location = new System.Drawing.Point(102, 174);
            this.label_InputWithdrawAmount.Name = "label_InputWithdrawAmount";
            this.label_InputWithdrawAmount.Size = new System.Drawing.Size(141, 16);
            this.label_InputWithdrawAmount.TabIndex = 16;
            this.label_InputWithdrawAmount.Text = "Input Withdraw Amount";
            // 
            // label_Balance
            // 
            this.label_Balance.AutoSize = true;
            this.label_Balance.Location = new System.Drawing.Point(166, 148);
            this.label_Balance.Name = "label_Balance";
            this.label_Balance.Size = new System.Drawing.Size(14, 16);
            this.label_Balance.TabIndex = 20;
            this.label_Balance.Text = "0";
            // 
            // label_BalanceText
            // 
            this.label_BalanceText.AutoSize = true;
            this.label_BalanceText.Location = new System.Drawing.Point(90, 148);
            this.label_BalanceText.Name = "label_BalanceText";
            this.label_BalanceText.Size = new System.Drawing.Size(57, 16);
            this.label_BalanceText.TabIndex = 19;
            this.label_BalanceText.Text = "Balance";
            // 
            // Withdraw_Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_Balance);
            this.Controls.Add(this.label_BalanceText);
            this.Controls.Add(this.tBox_WithdrawAmount);
            this.Controls.Add(this.btn_WithdrawMoney);
            this.Controls.Add(this.label_InputWithdrawAmount);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.label_UCBank);
            this.Name = "Withdraw_Interface";
            this.Text = "Withdraw_Interface";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Label label_UCBank;
        private System.Windows.Forms.TextBox tBox_WithdrawAmount;
        private System.Windows.Forms.Button btn_WithdrawMoney;
        private System.Windows.Forms.Label label_InputWithdrawAmount;
        private System.Windows.Forms.Label label_Balance;
        private System.Windows.Forms.Label label_BalanceText;
    }
}