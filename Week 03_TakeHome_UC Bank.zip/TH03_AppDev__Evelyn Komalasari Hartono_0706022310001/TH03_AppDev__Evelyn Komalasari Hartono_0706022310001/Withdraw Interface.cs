﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev__Evelyn_Komalasari_Hartono_0706022310001
{
    public partial class Withdraw_Interface : Form
    {
        public Withdraw_Interface()
        {
            InitializeComponent();
            Rekening selectedRekening = Data_Applicationcs.daftarRekening[Data_Applicationcs.foundRekeningIndex];
            label_Balance.Text = selectedRekening.BalanceInRupiah();
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            Form1 MainPage = new Form1();
            MainPage.Show();
            this.Hide();
        }

        private void btn_WithdrawMoney_Click(object sender, EventArgs e)
        {
            double currentRekeningBalance = Data_Applicationcs.daftarRekening[Data_Applicationcs.foundRekeningIndex].balance;
            double inputtedWithdrawAmount = Convert.ToDouble(tBox_WithdrawAmount.Text);
            if (inputtedWithdrawAmount < 1)
            {
                MessageBox.Show("Withdraw Amount Can't be Less Than 1");
            }
            else if (currentRekeningBalance < inputtedWithdrawAmount)
            {
                MessageBox.Show("Withdraw Amount Can't be More Than Current Balance");
            }
            else 
            {
                Data_Applicationcs.daftarRekening[Data_Applicationcs.foundRekeningIndex].Withdraw(Convert.ToDouble(tBox_WithdrawAmount.Text));
                MessageBox.Show("Successfully Withdrawed");
                Interface_Rekening Rekening_Interface = new Interface_Rekening();
                Rekening_Interface.Show();
                this.Hide();
            }
        }
    }
}
