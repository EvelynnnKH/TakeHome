﻿namespace Week_04_TakeHome_FootballTeam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_SoccerTeamList = new System.Windows.Forms.Label();
            this.label_ChooseCountry = new System.Windows.Forms.Label();
            this.label_ChooseTeam = new System.Windows.Forms.Label();
            this.comboBox_Country = new System.Windows.Forms.ComboBox();
            this.comboBox_Team = new System.Windows.Forms.ComboBox();
            this.listBox_PlayersName = new System.Windows.Forms.ListBox();
            this.btn_RemoveName = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label_TeamName = new System.Windows.Forms.Label();
            this.label_AddingTeam = new System.Windows.Forms.Label();
            this.label_TeamCity = new System.Windows.Forms.Label();
            this.tBox_InputTeamName = new System.Windows.Forms.TextBox();
            this.tBox_InputTeamCountry = new System.Windows.Forms.TextBox();
            this.tBox_InputTeamCity = new System.Windows.Forms.TextBox();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.tBox_InputPlayerNumber = new System.Windows.Forms.TextBox();
            this.tBox_InputPlayerName = new System.Windows.Forms.TextBox();
            this.label_PlayerPosition = new System.Windows.Forms.Label();
            this.label_PlayerNumber = new System.Windows.Forms.Label();
            this.label_PlayerName = new System.Windows.Forms.Label();
            this.label_AddingPLayers = new System.Windows.Forms.Label();
            this.comboBox_InputPlayerPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label_SoccerTeamList
            // 
            this.label_SoccerTeamList.AutoSize = true;
            this.label_SoccerTeamList.Location = new System.Drawing.Point(65, 87);
            this.label_SoccerTeamList.Name = "label_SoccerTeamList";
            this.label_SoccerTeamList.Size = new System.Drawing.Size(112, 16);
            this.label_SoccerTeamList.TabIndex = 0;
            this.label_SoccerTeamList.Text = "Soccer Team List";
            // 
            // label_ChooseCountry
            // 
            this.label_ChooseCountry.AutoSize = true;
            this.label_ChooseCountry.Location = new System.Drawing.Point(65, 123);
            this.label_ChooseCountry.Name = "label_ChooseCountry";
            this.label_ChooseCountry.Size = new System.Drawing.Size(105, 16);
            this.label_ChooseCountry.TabIndex = 1;
            this.label_ChooseCountry.Text = "Choose Country:";
            // 
            // label_ChooseTeam
            // 
            this.label_ChooseTeam.AutoSize = true;
            this.label_ChooseTeam.Location = new System.Drawing.Point(65, 162);
            this.label_ChooseTeam.Name = "label_ChooseTeam";
            this.label_ChooseTeam.Size = new System.Drawing.Size(96, 16);
            this.label_ChooseTeam.TabIndex = 2;
            this.label_ChooseTeam.Text = "Choose Team:";
            // 
            // comboBox_Country
            // 
            this.comboBox_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Country.FormattingEnabled = true;
            this.comboBox_Country.Location = new System.Drawing.Point(185, 120);
            this.comboBox_Country.Name = "comboBox_Country";
            this.comboBox_Country.Size = new System.Drawing.Size(121, 24);
            this.comboBox_Country.TabIndex = 3;
            this.comboBox_Country.SelectedValueChanged += new System.EventHandler(this.comboBox_Country_SelectedValueChanged);
            // 
            // comboBox_Team
            // 
            this.comboBox_Team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Team.FormattingEnabled = true;
            this.comboBox_Team.Location = new System.Drawing.Point(185, 159);
            this.comboBox_Team.Name = "comboBox_Team";
            this.comboBox_Team.Size = new System.Drawing.Size(121, 24);
            this.comboBox_Team.TabIndex = 4;
            this.comboBox_Team.SelectedValueChanged += new System.EventHandler(this.comboBox_Team_SelectedValueChanged);
            // 
            // listBox_PlayersName
            // 
            this.listBox_PlayersName.FormattingEnabled = true;
            this.listBox_PlayersName.ItemHeight = 16;
            this.listBox_PlayersName.Location = new System.Drawing.Point(68, 211);
            this.listBox_PlayersName.Name = "listBox_PlayersName";
            this.listBox_PlayersName.Size = new System.Drawing.Size(238, 132);
            this.listBox_PlayersName.TabIndex = 5;
            // 
            // btn_RemoveName
            // 
            this.btn_RemoveName.Location = new System.Drawing.Point(68, 360);
            this.btn_RemoveName.Name = "btn_RemoveName";
            this.btn_RemoveName.Size = new System.Drawing.Size(93, 25);
            this.btn_RemoveName.TabIndex = 6;
            this.btn_RemoveName.Text = "Remove";
            this.btn_RemoveName.UseVisualStyleBackColor = true;
            this.btn_RemoveName.Click += new System.EventHandler(this.btn_RemoveName_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(350, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Team Country:";
            // 
            // label_TeamName
            // 
            this.label_TeamName.AutoSize = true;
            this.label_TeamName.Location = new System.Drawing.Point(350, 123);
            this.label_TeamName.Name = "label_TeamName";
            this.label_TeamName.Size = new System.Drawing.Size(86, 16);
            this.label_TeamName.TabIndex = 8;
            this.label_TeamName.Text = "Team Name:";
            // 
            // label_AddingTeam
            // 
            this.label_AddingTeam.AutoSize = true;
            this.label_AddingTeam.Location = new System.Drawing.Point(466, 87);
            this.label_AddingTeam.Name = "label_AddingTeam";
            this.label_AddingTeam.Size = new System.Drawing.Size(89, 16);
            this.label_AddingTeam.TabIndex = 7;
            this.label_AddingTeam.Text = "Adding Team";
            // 
            // label_TeamCity
            // 
            this.label_TeamCity.AutoSize = true;
            this.label_TeamCity.Location = new System.Drawing.Point(350, 203);
            this.label_TeamCity.Name = "label_TeamCity";
            this.label_TeamCity.Size = new System.Drawing.Size(71, 16);
            this.label_TeamCity.TabIndex = 12;
            this.label_TeamCity.Text = "Team City:";
            // 
            // tBox_InputTeamName
            // 
            this.tBox_InputTeamName.Location = new System.Drawing.Point(469, 121);
            this.tBox_InputTeamName.Name = "tBox_InputTeamName";
            this.tBox_InputTeamName.Size = new System.Drawing.Size(142, 22);
            this.tBox_InputTeamName.TabIndex = 13;
            // 
            // tBox_InputTeamCountry
            // 
            this.tBox_InputTeamCountry.Location = new System.Drawing.Point(469, 161);
            this.tBox_InputTeamCountry.Name = "tBox_InputTeamCountry";
            this.tBox_InputTeamCountry.Size = new System.Drawing.Size(142, 22);
            this.tBox_InputTeamCountry.TabIndex = 14;
            // 
            // tBox_InputTeamCity
            // 
            this.tBox_InputTeamCity.Location = new System.Drawing.Point(469, 200);
            this.tBox_InputTeamCity.Name = "tBox_InputTeamCity";
            this.tBox_InputTeamCity.Size = new System.Drawing.Size(142, 22);
            this.tBox_InputTeamCity.TabIndex = 15;
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Location = new System.Drawing.Point(469, 239);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(78, 25);
            this.btn_AddTeam.TabIndex = 16;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.Location = new System.Drawing.Point(770, 239);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(78, 25);
            this.btn_AddPlayer.TabIndex = 24;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = true;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // tBox_InputPlayerNumber
            // 
            this.tBox_InputPlayerNumber.Location = new System.Drawing.Point(770, 161);
            this.tBox_InputPlayerNumber.Name = "tBox_InputPlayerNumber";
            this.tBox_InputPlayerNumber.Size = new System.Drawing.Size(142, 22);
            this.tBox_InputPlayerNumber.TabIndex = 22;
            // 
            // tBox_InputPlayerName
            // 
            this.tBox_InputPlayerName.Location = new System.Drawing.Point(770, 121);
            this.tBox_InputPlayerName.Name = "tBox_InputPlayerName";
            this.tBox_InputPlayerName.Size = new System.Drawing.Size(142, 22);
            this.tBox_InputPlayerName.TabIndex = 21;
            // 
            // label_PlayerPosition
            // 
            this.label_PlayerPosition.AutoSize = true;
            this.label_PlayerPosition.Location = new System.Drawing.Point(651, 203);
            this.label_PlayerPosition.Name = "label_PlayerPosition";
            this.label_PlayerPosition.Size = new System.Drawing.Size(100, 16);
            this.label_PlayerPosition.TabIndex = 20;
            this.label_PlayerPosition.Text = "Player Position:";
            // 
            // label_PlayerNumber
            // 
            this.label_PlayerNumber.AutoSize = true;
            this.label_PlayerNumber.Location = new System.Drawing.Point(651, 162);
            this.label_PlayerNumber.Name = "label_PlayerNumber";
            this.label_PlayerNumber.Size = new System.Drawing.Size(103, 16);
            this.label_PlayerNumber.TabIndex = 19;
            this.label_PlayerNumber.Text = "Player Number: ";
            // 
            // label_PlayerName
            // 
            this.label_PlayerName.AutoSize = true;
            this.label_PlayerName.Location = new System.Drawing.Point(651, 123);
            this.label_PlayerName.Name = "label_PlayerName";
            this.label_PlayerName.Size = new System.Drawing.Size(89, 16);
            this.label_PlayerName.TabIndex = 18;
            this.label_PlayerName.Text = "Player Name:";
            // 
            // label_AddingPLayers
            // 
            this.label_AddingPLayers.AutoSize = true;
            this.label_AddingPLayers.Location = new System.Drawing.Point(767, 87);
            this.label_AddingPLayers.Name = "label_AddingPLayers";
            this.label_AddingPLayers.Size = new System.Drawing.Size(92, 16);
            this.label_AddingPLayers.TabIndex = 17;
            this.label_AddingPLayers.Text = "Adding Player";
            // 
            // comboBox_InputPlayerPosition
            // 
            this.comboBox_InputPlayerPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_InputPlayerPosition.FormattingEnabled = true;
            this.comboBox_InputPlayerPosition.Location = new System.Drawing.Point(770, 199);
            this.comboBox_InputPlayerPosition.Name = "comboBox_InputPlayerPosition";
            this.comboBox_InputPlayerPosition.Size = new System.Drawing.Size(142, 24);
            this.comboBox_InputPlayerPosition.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 450);
            this.Controls.Add(this.tBox_InputTeamCountry);
            this.Controls.Add(this.label_AddingTeam);
            this.Controls.Add(this.comboBox_InputPlayerPosition);
            this.Controls.Add(this.label_TeamName);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tBox_InputPlayerNumber);
            this.Controls.Add(this.label_TeamCity);
            this.Controls.Add(this.tBox_InputPlayerName);
            this.Controls.Add(this.tBox_InputTeamName);
            this.Controls.Add(this.label_PlayerPosition);
            this.Controls.Add(this.tBox_InputTeamCity);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.label_PlayerNumber);
            this.Controls.Add(this.label_PlayerName);
            this.Controls.Add(this.label_AddingPLayers);
            this.Controls.Add(this.btn_RemoveName);
            this.Controls.Add(this.listBox_PlayersName);
            this.Controls.Add(this.comboBox_Team);
            this.Controls.Add(this.comboBox_Country);
            this.Controls.Add(this.label_ChooseTeam);
            this.Controls.Add(this.label_ChooseCountry);
            this.Controls.Add(this.label_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_SoccerTeamList;
        private System.Windows.Forms.Label label_ChooseCountry;
        private System.Windows.Forms.Label label_ChooseTeam;
        private System.Windows.Forms.ComboBox comboBox_Country;
        private System.Windows.Forms.ComboBox comboBox_Team;
        private System.Windows.Forms.ListBox listBox_PlayersName;
        private System.Windows.Forms.Button btn_RemoveName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_TeamName;
        private System.Windows.Forms.Label label_AddingTeam;
        private System.Windows.Forms.Label label_TeamCity;
        private System.Windows.Forms.TextBox tBox_InputTeamName;
        private System.Windows.Forms.TextBox tBox_InputTeamCountry;
        private System.Windows.Forms.TextBox tBox_InputTeamCity;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayer;
        private System.Windows.Forms.TextBox tBox_InputPlayerNumber;
        private System.Windows.Forms.TextBox tBox_InputPlayerName;
        private System.Windows.Forms.Label label_PlayerPosition;
        private System.Windows.Forms.Label label_PlayerNumber;
        private System.Windows.Forms.Label label_PlayerName;
        private System.Windows.Forms.Label label_AddingPLayers;
        private System.Windows.Forms.ComboBox comboBox_InputPlayerPosition;
    }
}

