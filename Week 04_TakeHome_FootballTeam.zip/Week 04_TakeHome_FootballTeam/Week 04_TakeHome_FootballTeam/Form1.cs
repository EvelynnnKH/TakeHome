﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Week_04_TakeHome_FootballTeam
{
    public partial class Form1 : Form
    {
        Team_Class selectedTeamByUser;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List_of_Teams.teams = new List<Team_Class>();
            FirstTeam();
            SecondTeam();
            ThirdTeam();
            List<string> teamPos = new List<string>();
            teamPos.Add("GK");
            teamPos.Add("MF");
            teamPos.Add("FW");
            teamPos.Add("DF");
            comboBox_InputPlayerPosition.DataSource = teamPos;
        }
        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            if (tBox_InputTeamName.Text == "" || tBox_InputTeamCountry.Text == "" || tBox_InputTeamCity.Text == "")
            {
                MessageBox.Show("Please Fill All the Box");
            }
            else if (containDoubleTeam() == true)
            {
                MessageBox.Show("Team Has Been Inputted");
            }
            else
            {
                AddTeam(tBox_InputTeamName.Text, tBox_InputTeamCountry.Text, tBox_InputTeamCity.Text);
            }
        }

        private bool containDoubleTeam()
        {
            for (int i = 0; i < List_of_Teams.teams.Count; i++)
            {
                if (tBox_InputTeamName.Text == List_of_Teams.teams[i].teamName)
                {
                    return true;
                }
            }
            return false;
        }

        private Team_Class AddTeam(string teamName, string teamCountry, string teamCIty)
        {
            Team_Class team = new Team_Class(teamName, teamCountry, teamCIty); // number value? mirip sm listbox kok
            List_of_Teams.teams.Add(team);
            List<string> listOfCountry = new List<string>();

            for (int i = 0; i < List_of_Teams.teams.Count; i++)
            {
                if (listOfCountry.Contains(List_of_Teams.teams[i].teamCountry) == false)
                {
                    listOfCountry.Add(List_of_Teams.teams[i].teamCountry);
                }
            }
            comboBox_Country.DataSource = listOfCountry;
            comboBox_Country.SelectedItem = null;
            return team;
        }

        private void btn_RemoveName_Click(object sender, EventArgs e)
        {
            if (selectedTeamByUser.players.Count > 11)
            {
                string num = listBox_PlayersName.SelectedValue.ToString().Substring(1, 2);
                for (int i = 0; i < selectedTeamByUser.players.Count; i++)
                {
                    if (selectedTeamByUser.players[i].playerNum == num)
                    {
                        selectedTeamByUser.players.RemoveAt(i);
                        showPlayersIfPossible();
                        break;
                    }
                }
            }
            else
            {
                MessageBox.Show("Player Cannot Be Less Than 11");
            }
        }
        private void FirstTeam()
        {
            Team_Class firstTeam = AddTeam("Arema Football Club", "Indonesia", "Malang");
            firstTeam.AddingPlayer(new Player ("Teguh Amiruddin", "23", "GK"));
            firstTeam.AddingPlayer(new Player("Dicki Agung", "22", "GK"));
            firstTeam.AddingPlayer(new Player("Syaeful", "04", "DF"));
            firstTeam.AddingPlayer(new Player("Asyraq Gufron", "25", "DF"));
            firstTeam.AddingPlayer(new Player("Bayu Aji", "03", "DF"));
            firstTeam.AddingPlayer(new Player("Jayus Hariono", "14", "MF"));
            firstTeam.AddingPlayer(new Player("Evan Dimas", "09", "MF"));
            firstTeam.AddingPlayer(new Player("Muhammad Rafli", "10", "MF"));
            firstTeam.AddingPlayer(new Player("Dendi Santoso", "41", "FW"));
            firstTeam.AddingPlayer(new Player("Dedik Setiawan", "27", "FW"));
            firstTeam.AddingPlayer(new Player("Flabio Soares", "21", "FW"));
        }
        private void SecondTeam()
        {
            Team_Class secondTeam = AddTeam("Persija Club", "Indonesia", "Jakarta");
            secondTeam.AddingPlayer(new Player("Cahya Supriyadi", "50", "GK"));
            secondTeam.AddingPlayer(new Player("Tony Sucipto", "06", "DF"));
            secondTeam.AddingPlayer(new Player("Riko Simanjuntak", "25", "MF"));
            secondTeam.AddingPlayer(new Player("Muhammad Ferarri", "41", "DF"));
            secondTeam.AddingPlayer(new Player("Marko Simic", "09", "FW"));
            secondTeam.AddingPlayer(new Player("Dony Tri Pamungkas", "77", "MF"));
            secondTeam.AddingPlayer(new Player("Ilham Rio Fahmi", "02", "DF"));
            secondTeam.AddingPlayer(new Player("Maman Abdurahman", "56", "DF"));
            secondTeam.AddingPlayer(new Player("Syahrian Abimanyu", "08", "MF"));
            secondTeam.AddingPlayer(new Player("Adre Arido Geovani", "13", "GK"));
            secondTeam.AddingPlayer(new Player("Aji Kusuma", "99", "FW"));
        }
        private void ThirdTeam()
        {
            Team_Class thirdTeam = AddTeam("Real Madrid", "Spanyol", "Madrid");
            thirdTeam.AddingPlayer(new Player("Thibaut Courtois", "01", "GK"));
            thirdTeam.AddingPlayer(new Player("Dani Carvajal", "02", "DF"));
            thirdTeam.AddingPlayer(new Player("Eder Militao", "03", "DF"));
            thirdTeam.AddingPlayer(new Player("David Alaba", "04", "DF"));
            thirdTeam.AddingPlayer(new Player("Jude Bellingham", "05", "MF"));
            thirdTeam.AddingPlayer(new Player("Nacho", "06", "DF"));
            thirdTeam.AddingPlayer(new Player("Vinicius Junior", "07", "FW"));
            thirdTeam.AddingPlayer(new Player("Toni Kroos", "08", "MF"));
            thirdTeam.AddingPlayer(new Player("Luka Modric", "10", "MF"));
            thirdTeam.AddingPlayer(new Player("Rodrygo", "11", "FW"));
            thirdTeam.AddingPlayer(new Player("Eduardo Carnavinga", "12", "MF"));
        }
        private void comboBox_Team_SelectedValueChanged(object sender, EventArgs e)
        {
            showPlayersIfPossible();
        }
        private void comboBox_Country_SelectedValueChanged(object sender, EventArgs e)
        {
            List<string> listOfTeamName = new List<string>();
            string selectedCountry = "";
            if (comboBox_Country.SelectedValue != null)
            {
                selectedCountry = comboBox_Country.SelectedValue.ToString();
            }
            for (int i = 0; i < List_of_Teams.teams.Count; i++)
            {
                if (selectedCountry == List_of_Teams.teams[i].teamCountry)
                {
                    listOfTeamName.Add(List_of_Teams.teams[i].teamName);
                }
            }
            comboBox_Team.DataSource = listOfTeamName;
            comboBox_Team.SelectedItem = null;
            showPlayersIfPossible();
        }
        private void showPlayersIfPossible()
        {
            string selectedCountry = "";
            string selectedTeam = "";
            if (comboBox_Country.SelectedValue != null)
            {
                selectedCountry = comboBox_Country.SelectedValue.ToString();
            }
            if (comboBox_Team.SelectedValue != null)
            {
                selectedTeam = comboBox_Team.SelectedValue.ToString();
            }
            List<string> selectedTeamPlayers = new List<string>();
            for (int i = 0;  i < List_of_Teams.teams.Count; i++)
            {
                if (List_of_Teams.teams[i].teamCountry == selectedCountry && List_of_Teams.teams[i].teamName == selectedTeam)
                {
                    selectedTeamByUser = List_of_Teams.teams[i];
                    for (int j = 0; j < List_of_Teams.teams[i].players.Count; j++)
                    {
                        selectedTeamPlayers.Add($"({List_of_Teams.teams[i].players[j].playerNum}) {List_of_Teams.teams[i].players[j].playerName}, {List_of_Teams.teams[i].players[j].playerPos}");
                    }

                }
            }
            selectedTeamPlayers.Sort();
            listBox_PlayersName.DataSource = selectedTeamPlayers;
        }

        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            if (tBox_InputPlayerName.Text == "" || tBox_InputPlayerNumber.Text == "" || comboBox_InputPlayerPosition.SelectedValue == null)
            {
                MessageBox.Show("Please Fill All the Box");
            }
            else if (containsDoublePlayer() == true)
            {
                MessageBox.Show("Player Has Been Inputted");
            }
            else if (comboBox_Team.SelectedValue == null)
            {
                MessageBox.Show("Please Choose A Team First");
            }
            else
            {
                selectedTeamByUser.AddingPlayer(new Player(tBox_InputPlayerName.Text, tBox_InputPlayerNumber.Text, comboBox_InputPlayerPosition.SelectedValue.ToString()));
                showPlayersIfPossible();
            }
        }
        private bool containsDoublePlayer()
        {
            for (int i = 0; i < selectedTeamByUser.players.Count; i++)
            {
                if (selectedTeamByUser.players[i].playerName == tBox_InputPlayerName.Text)
                {
                    return true;
                }
                if (selectedTeamByUser.players[i].playerNum == tBox_InputPlayerNumber.Text) 
                { 
                    return true; 
                }
            }
            return false;
        }

    }
}
