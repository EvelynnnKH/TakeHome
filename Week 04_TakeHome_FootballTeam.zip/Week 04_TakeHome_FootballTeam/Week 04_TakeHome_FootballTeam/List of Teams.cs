﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_04_TakeHome_FootballTeam
{
    internal class List_of_Teams
    {
        public static List<Team_Class> teams; 

        public List_of_Teams (Team_Class team_Class) 
        {
            teams.Add(team_Class);
        }
    }


}
