﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_04_TakeHome_FootballTeam
{
    internal class Team_Class
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Player> players =new List<Player>();

        public Team_Class(string teamName, string teamCountry, string teamCity)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            this.DisplayedTeamName = teamName;
        }

        public void AddingPlayer(Player player)
        {
            this.players.Add(player);
        }
        public string DisplayedTeamName
        {
            get; 
            set;
        }
    }
}
