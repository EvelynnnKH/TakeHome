﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_05_TakeHome_FashionStock
{
    internal class Category
    {
        public string categoryID;
        public string categoryName;
        public Category(string categoryName, string categoryID)
        {
            this.categoryName = categoryName;  
            this.categoryID = categoryID;
        }
    }
}
