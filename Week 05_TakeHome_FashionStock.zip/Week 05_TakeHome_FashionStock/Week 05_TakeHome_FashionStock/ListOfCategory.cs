﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_05_TakeHome_FashionStock
{
    internal class ListOfCategory
    {
        private static List<Category> categories = new List<Category>();

        public static List<Category> Categories { get { return categories; } }

        public static string FindCategoryName (string categoryID)
        {
            string categoryName = "";
            foreach (Category category in categories)
            {
                if (category.categoryID == categoryID)
                {
                    categoryName = category.categoryName;
                }
            }
            return categoryName;
        }

        public static Category InputTheSameCategory(string categoryName)
        {
            string categoryID = "";
            for (int i = 0; i < categories.Count; i++)
            {
                if (categories[i].categoryName == categoryName)
                {
                    categoryID = categories[i].categoryID;
                }
            }
            return new Category (categoryName, categoryID);
        }

        public static Category MakingCategory (string newCategoryName)
        {
            Category category;
            if (ListOfCategory.categories.Count == 0)
            {
                category = new Category(newCategoryName, "C" + 1);
                ListOfCategory.categories.Add(category);
            }
            else
            {
                int urutan = 0;
                int banyakSubstring = -1;
                for (int i = 0; i < ListOfCategory.categories[ListOfCategory.categories.Count - 1].categoryID.Length; i++)
                {
                    urutan++;
                    banyakSubstring++;
                }
                int angkaDiCari = Convert.ToInt32(ListOfCategory.categories[ListOfCategory.categories.Count - 1].categoryID.Substring(urutan - 1, banyakSubstring));
                category = new Category(newCategoryName, "C" + (angkaDiCari + 1));
                ListOfCategory.categories.Add(category);
            }
            return category;
        }

        public static bool IsThereAnySimilarCategory (string categoryName)
        {
            bool sudahAda = false;
            for (int i = 0; i < ListOfCategory.categories.Count; i++)
            {
                if (ListOfCategory.categories[i].categoryName == categoryName)
                {
                    sudahAda = true;
                }
            }
            return (categoryName != null && sudahAda == false);   
        }

        public static void RemoveACategory (string categoryName)
        {
            for (int i = 0; i < ListOfCategory.categories.Count; i++)
            {
                if (ListOfCategory.categories[i].categoryName == categoryName)
                {
                    ListOfCategory.categories.RemoveAt(i);
                    break;
                }
            }
        }
    }
}
