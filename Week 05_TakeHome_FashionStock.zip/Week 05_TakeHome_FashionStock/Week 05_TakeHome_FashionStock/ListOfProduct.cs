﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_05_TakeHome_FashionStock
{
    internal class ListOfProduct
    {
        public static List<Product> Products = new List<Product>();

        public static void RemoveProductByCategoryName(string categoryName)
        {
            List<int> indexProductToBeRemoved = new List<int>();
            for (int i = 0; i < Products.Count; i++)
            {
                if (ListOfProduct.Products[i].productCategory.categoryName == categoryName)
                {
                    indexProductToBeRemoved.Add(i);
                }
            }
            for (int i = indexProductToBeRemoved.Count-1; i >= 0; i--)
            {
                ListOfProduct.Products.RemoveAt(indexProductToBeRemoved[i]);
            }
        }
    }
}
