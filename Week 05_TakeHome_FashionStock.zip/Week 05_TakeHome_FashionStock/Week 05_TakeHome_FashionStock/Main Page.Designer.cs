﻿namespace Week_05_TakeHome_FashionStock
{
    partial class form_MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.PictureBox pictureBox_NOTED;
            this.label_Product = new System.Windows.Forms.Label();
            this.label_Category = new System.Windows.Forms.Label();
            this.btn_ShowAll = new System.Windows.Forms.Button();
            this.dgv_ListOfProductOnStore = new System.Windows.Forms.DataGridView();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.comboBox_Filter = new System.Windows.Forms.ComboBox();
            this.dgv_CategoryIDs = new System.Windows.Forms.DataGridView();
            this.label_CategoryName = new System.Windows.Forms.Label();
            this.tBox_CategoryNameInputted = new System.Windows.Forms.TextBox();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.label_Details = new System.Windows.Forms.Label();
            this.tBox_ProductName = new System.Windows.Forms.TextBox();
            this.label_ProductName = new System.Windows.Forms.Label();
            this.tBox_ProductPrice = new System.Windows.Forms.TextBox();
            this.label_ProductPrice = new System.Windows.Forms.Label();
            this.tBox_ProductStock = new System.Windows.Forms.TextBox();
            this.label_ProductStock = new System.Windows.Forms.Label();
            this.label_ProductCategory = new System.Windows.Forms.Label();
            this.comboBox_CategoryNames = new System.Windows.Forms.ComboBox();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.pictureBox_Background = new System.Windows.Forms.PictureBox();
            pictureBox_NOTED = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(pictureBox_NOTED)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ListOfProductOnStore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CategoryIDs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Background)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_NOTED
            // 
            pictureBox_NOTED.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            pictureBox_NOTED.BackColor = System.Drawing.Color.LightSalmon;
            pictureBox_NOTED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            pictureBox_NOTED.Image = global::Week_05_TakeHome_FashionStock.Properties.Resources.tst_small_507x507_pad_600x600_f8f8f8_removebg_preview;
            pictureBox_NOTED.Location = new System.Drawing.Point(597, 372);
            pictureBox_NOTED.Name = "pictureBox_NOTED";
            pictureBox_NOTED.Size = new System.Drawing.Size(294, 227);
            pictureBox_NOTED.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox_NOTED.TabIndex = 24;
            pictureBox_NOTED.TabStop = false;
            // 
            // label_Product
            // 
            this.label_Product.AutoSize = true;
            this.label_Product.BackColor = System.Drawing.Color.LightSalmon;
            this.label_Product.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Product.Font = new System.Drawing.Font("Tahoma", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Product.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label_Product.Location = new System.Drawing.Point(79, 49);
            this.label_Product.Name = "label_Product";
            this.label_Product.Size = new System.Drawing.Size(99, 27);
            this.label_Product.TabIndex = 1;
            this.label_Product.Text = "Product";
            // 
            // label_Category
            // 
            this.label_Category.AutoSize = true;
            this.label_Category.BackColor = System.Drawing.Color.LightSalmon;
            this.label_Category.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Category.Font = new System.Drawing.Font("Tahoma", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Category.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label_Category.Location = new System.Drawing.Point(655, 49);
            this.label_Category.Name = "label_Category";
            this.label_Category.Size = new System.Drawing.Size(113, 27);
            this.label_Category.TabIndex = 2;
            this.label_Category.Text = "Category";
            // 
            // btn_ShowAll
            // 
            this.btn_ShowAll.BackColor = System.Drawing.Color.White;
            this.btn_ShowAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_ShowAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ShowAll.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ShowAll.Location = new System.Drawing.Point(361, 70);
            this.btn_ShowAll.Name = "btn_ShowAll";
            this.btn_ShowAll.Size = new System.Drawing.Size(37, 25);
            this.btn_ShowAll.TabIndex = 3;
            this.btn_ShowAll.Text = "All";
            this.btn_ShowAll.UseVisualStyleBackColor = false;
            this.btn_ShowAll.Click += new System.EventHandler(this.btn_ShowAll_Click);
            // 
            // dgv_ListOfProductOnStore
            // 
            this.dgv_ListOfProductOnStore.AllowUserToAddRows = false;
            this.dgv_ListOfProductOnStore.AllowUserToDeleteRows = false;
            this.dgv_ListOfProductOnStore.AllowUserToResizeColumns = false;
            this.dgv_ListOfProductOnStore.AllowUserToResizeRows = false;
            this.dgv_ListOfProductOnStore.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgv_ListOfProductOnStore.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ListOfProductOnStore.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_ListOfProductOnStore.Location = new System.Drawing.Point(84, 100);
            this.dgv_ListOfProductOnStore.MultiSelect = false;
            this.dgv_ListOfProductOnStore.Name = "dgv_ListOfProductOnStore";
            this.dgv_ListOfProductOnStore.RowHeadersVisible = false;
            this.dgv_ListOfProductOnStore.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
            this.dgv_ListOfProductOnStore.RowTemplate.Height = 24;
            this.dgv_ListOfProductOnStore.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_ListOfProductOnStore.Size = new System.Drawing.Size(507, 278);
            this.dgv_ListOfProductOnStore.TabIndex = 4;
            this.dgv_ListOfProductOnStore.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_ListOfProductOnStore_CellClick);
            // 
            // btn_Filter
            // 
            this.btn_Filter.BackColor = System.Drawing.Color.White;
            this.btn_Filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Filter.Location = new System.Drawing.Point(404, 70);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(60, 25);
            this.btn_Filter.TabIndex = 5;
            this.btn_Filter.Text = "Filter";
            this.btn_Filter.UseVisualStyleBackColor = false;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // comboBox_Filter
            // 
            this.comboBox_Filter.AllowDrop = true;
            this.comboBox_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Filter.Enabled = false;
            this.comboBox_Filter.FormattingEnabled = true;
            this.comboBox_Filter.Location = new System.Drawing.Point(470, 70);
            this.comboBox_Filter.Name = "comboBox_Filter";
            this.comboBox_Filter.Size = new System.Drawing.Size(121, 24);
            this.comboBox_Filter.TabIndex = 6;
            this.comboBox_Filter.SelectedIndexChanged += new System.EventHandler(this.comboBox_Filter_SelectedIndexChanged);
            // 
            // dgv_CategoryIDs
            // 
            this.dgv_CategoryIDs.AllowUserToAddRows = false;
            this.dgv_CategoryIDs.AllowUserToDeleteRows = false;
            this.dgv_CategoryIDs.AllowUserToResizeColumns = false;
            this.dgv_CategoryIDs.AllowUserToResizeRows = false;
            this.dgv_CategoryIDs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgv_CategoryIDs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CategoryIDs.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_CategoryIDs.Location = new System.Drawing.Point(642, 99);
            this.dgv_CategoryIDs.MultiSelect = false;
            this.dgv_CategoryIDs.Name = "dgv_CategoryIDs";
            this.dgv_CategoryIDs.RowHeadersVisible = false;
            this.dgv_CategoryIDs.RowHeadersWidth = 51;
            this.dgv_CategoryIDs.RowTemplate.Height = 24;
            this.dgv_CategoryIDs.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_CategoryIDs.Size = new System.Drawing.Size(249, 193);
            this.dgv_CategoryIDs.TabIndex = 7;
            this.dgv_CategoryIDs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CategoryIDs_CellClick);
            // 
            // label_CategoryName
            // 
            this.label_CategoryName.AutoSize = true;
            this.label_CategoryName.BackColor = System.Drawing.Color.LightSalmon;
            this.label_CategoryName.Location = new System.Drawing.Point(640, 301);
            this.label_CategoryName.Name = "label_CategoryName";
            this.label_CategoryName.Size = new System.Drawing.Size(47, 16);
            this.label_CategoryName.TabIndex = 8;
            this.label_CategoryName.Text = "Nama:";
            // 
            // tBox_CategoryNameInputted
            // 
            this.tBox_CategoryNameInputted.Location = new System.Drawing.Point(688, 298);
            this.tBox_CategoryNameInputted.Name = "tBox_CategoryNameInputted";
            this.tBox_CategoryNameInputted.Size = new System.Drawing.Size(203, 22);
            this.tBox_CategoryNameInputted.TabIndex = 9;
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveCategory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_RemoveCategory.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RemoveCategory.Location = new System.Drawing.Point(819, 326);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(72, 59);
            this.btn_RemoveCategory.TabIndex = 10;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = false;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_AddCategory.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddCategory.Location = new System.Drawing.Point(741, 326);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(72, 59);
            this.btn_AddCategory.TabIndex = 11;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // label_Details
            // 
            this.label_Details.AutoSize = true;
            this.label_Details.BackColor = System.Drawing.Color.LightSalmon;
            this.label_Details.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Details.Font = new System.Drawing.Font("Tahoma", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label_Details.Location = new System.Drawing.Point(88, 402);
            this.label_Details.Name = "label_Details";
            this.label_Details.Size = new System.Drawing.Size(89, 27);
            this.label_Details.TabIndex = 12;
            this.label_Details.Text = "Details";
            // 
            // tBox_ProductName
            // 
            this.tBox_ProductName.Location = new System.Drawing.Point(160, 443);
            this.tBox_ProductName.Name = "tBox_ProductName";
            this.tBox_ProductName.Size = new System.Drawing.Size(431, 22);
            this.tBox_ProductName.TabIndex = 14;
            // 
            // label_ProductName
            // 
            this.label_ProductName.AutoSize = true;
            this.label_ProductName.BackColor = System.Drawing.Color.LightSalmon;
            this.label_ProductName.Location = new System.Drawing.Point(98, 446);
            this.label_ProductName.Name = "label_ProductName";
            this.label_ProductName.Size = new System.Drawing.Size(47, 16);
            this.label_ProductName.TabIndex = 13;
            this.label_ProductName.Text = "Nama:";
            // 
            // tBox_ProductPrice
            // 
            this.tBox_ProductPrice.Location = new System.Drawing.Point(160, 503);
            this.tBox_ProductPrice.Name = "tBox_ProductPrice";
            this.tBox_ProductPrice.Size = new System.Drawing.Size(141, 22);
            this.tBox_ProductPrice.TabIndex = 16;
            this.tBox_ProductPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_ProductPrice_KeyPress);
            // 
            // label_ProductPrice
            // 
            this.label_ProductPrice.AutoSize = true;
            this.label_ProductPrice.BackColor = System.Drawing.Color.LightSalmon;
            this.label_ProductPrice.Location = new System.Drawing.Point(103, 506);
            this.label_ProductPrice.Name = "label_ProductPrice";
            this.label_ProductPrice.Size = new System.Drawing.Size(41, 16);
            this.label_ProductPrice.TabIndex = 15;
            this.label_ProductPrice.Text = "Price:";
            // 
            // tBox_ProductStock
            // 
            this.tBox_ProductStock.Location = new System.Drawing.Point(160, 531);
            this.tBox_ProductStock.Name = "tBox_ProductStock";
            this.tBox_ProductStock.Size = new System.Drawing.Size(141, 22);
            this.tBox_ProductStock.TabIndex = 18;
            this.tBox_ProductStock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_ProductStock_KeyPress);
            // 
            // label_ProductStock
            // 
            this.label_ProductStock.AutoSize = true;
            this.label_ProductStock.BackColor = System.Drawing.Color.LightSalmon;
            this.label_ProductStock.Location = new System.Drawing.Point(99, 534);
            this.label_ProductStock.Name = "label_ProductStock";
            this.label_ProductStock.Size = new System.Drawing.Size(44, 16);
            this.label_ProductStock.TabIndex = 17;
            this.label_ProductStock.Text = "Stock:";
            // 
            // label_ProductCategory
            // 
            this.label_ProductCategory.AutoSize = true;
            this.label_ProductCategory.BackColor = System.Drawing.Color.LightSalmon;
            this.label_ProductCategory.Location = new System.Drawing.Point(80, 475);
            this.label_ProductCategory.Name = "label_ProductCategory";
            this.label_ProductCategory.Size = new System.Drawing.Size(65, 16);
            this.label_ProductCategory.TabIndex = 19;
            this.label_ProductCategory.Text = "Category:";
            // 
            // comboBox_CategoryNames
            // 
            this.comboBox_CategoryNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CategoryNames.FormattingEnabled = true;
            this.comboBox_CategoryNames.Location = new System.Drawing.Point(160, 472);
            this.comboBox_CategoryNames.Name = "comboBox_CategoryNames";
            this.comboBox_CategoryNames.Size = new System.Drawing.Size(141, 24);
            this.comboBox_CategoryNames.TabIndex = 20;
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_AddProduct.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddProduct.Location = new System.Drawing.Point(363, 495);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(72, 58);
            this.btn_AddProduct.TabIndex = 22;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = false;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_EditProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_EditProduct.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditProduct.Location = new System.Drawing.Point(441, 494);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(72, 59);
            this.btn_EditProduct.TabIndex = 21;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_RemoveProduct.Font = new System.Drawing.Font("Microsoft Tai Le", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RemoveProduct.Location = new System.Drawing.Point(519, 494);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(72, 59);
            this.btn_RemoveProduct.TabIndex = 23;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = false;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // pictureBox_Background
            // 
            this.pictureBox_Background.BackColor = System.Drawing.Color.LightSalmon;
            this.pictureBox_Background.Location = new System.Drawing.Point(48, 20);
            this.pictureBox_Background.Name = "pictureBox_Background";
            this.pictureBox_Background.Size = new System.Drawing.Size(876, 591);
            this.pictureBox_Background.TabIndex = 0;
            this.pictureBox_Background.TabStop = false;
            // 
            // form_MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 661);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.tBox_ProductName);
            this.Controls.Add(this.dgv_ListOfProductOnStore);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(pictureBox_NOTED);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.comboBox_CategoryNames);
            this.Controls.Add(this.label_ProductCategory);
            this.Controls.Add(this.tBox_ProductStock);
            this.Controls.Add(this.label_ProductStock);
            this.Controls.Add(this.tBox_ProductPrice);
            this.Controls.Add(this.label_ProductPrice);
            this.Controls.Add(this.label_ProductName);
            this.Controls.Add(this.label_Details);
            this.Controls.Add(this.tBox_CategoryNameInputted);
            this.Controls.Add(this.label_CategoryName);
            this.Controls.Add(this.dgv_CategoryIDs);
            this.Controls.Add(this.comboBox_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_ShowAll);
            this.Controls.Add(this.label_Category);
            this.Controls.Add(this.label_Product);
            this.Controls.Add(this.pictureBox_Background);
            this.Name = "form_MainPage";
            this.Text = "Inventory Blink Shop";
            this.Load += new System.EventHandler(this.form_MainPage_Load);
            ((System.ComponentModel.ISupportInitialize)(pictureBox_NOTED)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ListOfProductOnStore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CategoryIDs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Background)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_Product;
        private System.Windows.Forms.Label label_Category;
        private System.Windows.Forms.Button btn_ShowAll;
        private System.Windows.Forms.DataGridView dgv_ListOfProductOnStore;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.DataGridView dgv_CategoryIDs;
        private System.Windows.Forms.Label label_CategoryName;
        private System.Windows.Forms.TextBox tBox_CategoryNameInputted;
        private System.Windows.Forms.Button btn_RemoveCategory;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Label label_Details;
        private System.Windows.Forms.TextBox tBox_ProductName;
        private System.Windows.Forms.Label label_ProductName;
        private System.Windows.Forms.TextBox tBox_ProductPrice;
        private System.Windows.Forms.Label label_ProductPrice;
        private System.Windows.Forms.TextBox tBox_ProductStock;
        private System.Windows.Forms.Label label_ProductStock;
        private System.Windows.Forms.Label label_ProductCategory;
        private System.Windows.Forms.ComboBox comboBox_CategoryNames;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.PictureBox pictureBox_Background;
        private System.Windows.Forms.ComboBox comboBox_Filter;
    }
}

