﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_05_TakeHome_FashionStock
{
    public partial class form_MainPage : Form
    {
        DataTable dtProdukSimpan;
        DataTable dtCategory;
        DataTable dtProdukTampil;
        public form_MainPage()
        {
            InitializeComponent();
        }
        private void form_MainPage_Load(object sender, EventArgs e)
        {
            dtProdukSimpan = new DataTable();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dgv_ListOfProductOnStore.DataSource = dtProdukSimpan;

            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dgv_CategoryIDs.DataSource = dtCategory;

            dtProdukTampil = new DataTable();
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            AddingFirstCatalogs();
            showCategories();
        }

        private void AddingFirstCatalogs()
        {
            Category jasCategory = ListOfCategory.MakingCategory("Jas");
            Category shirtCategory = ListOfCategory.MakingCategory("T-Shirt");
            Category rokCategory = ListOfCategory.MakingCategory("Rok");
            Category celanaCategory = ListOfCategory.MakingCategory("Celana");
            Category cawatCategory = ListOfCategory.MakingCategory("Cawat");
            ListOfProduct.Products.Add(new Product("Jas Hitam", "100000", "10", jasCategory));
            ListOfProduct.Products.Add(new Product("T-Shirt Black Pink", "70000", "20", shirtCategory));
            ListOfProduct.Products.Add(new Product("T-Shirt Obsessive", "75000", "16", shirtCategory));
            ListOfProduct.Products.Add(new Product("Rok Mini", "82000", "26", rokCategory));
            ListOfProduct.Products.Add(new Product("Jeans Biru", "90000", "5", celanaCategory));
            ListOfProduct.Products.Add(new Product("Celana Pendek Coklat", "60000", "11", celanaCategory));
            ListOfProduct.Products.Add(new Product("Cawat Blink-Blink", "1000000", "1", cawatCategory));
            ListOfProduct.Products.Add(new Product("Rocca Shirt", "50000", "8", shirtCategory));
            showProduct(true);
        }
        private void btn_ShowAll_Click(object sender, EventArgs e)
        {
            comboBox_Filter.SelectedIndex = -1;
            comboBox_Filter.Enabled = false;
            bool showAll = true;
            showProduct(showAll);
        }
        private void showProduct(bool showAll)
        {
            dtProdukSimpan.Clear();
            dtProdukTampil.Clear();
            if (showAll == true)
            {
                for (int i = 0; i < ListOfProduct.Products.Count; i++)
                {
                    dtProdukSimpan.Rows.Add(ListOfProduct.Products[i].productID, ListOfProduct.Products[i].productName, ListOfProduct.Products[i].productPrice, ListOfProduct.Products[i].productStock, ListOfProduct.Products[i].productCategory.categoryID);
                }
                dgv_ListOfProductOnStore.DataSource = dtProdukSimpan;
            }
            else if (showAll == false && comboBox_Filter.SelectedItem != null)
            {
                foreach (Product product in ListOfProduct.Products)
                {
                    if (product.productCategory.categoryName == comboBox_Filter.SelectedItem.ToString())
                    {
                        dtProdukTampil.Rows.Add(product.productID, product.productName, product.productPrice, product.productStock, product.productCategory.categoryID);
                    }
                }
                dgv_ListOfProductOnStore.DataSource = dtProdukTampil;
            }
        }
        private void showCategories()
        {
            dtCategory.Clear();
            comboBox_CategoryNames.Items.Clear();
            for (int i = 0; i < ListOfCategory.Categories.Count; i++)
            {
                dtCategory.Rows.Add(ListOfCategory.Categories[i].categoryID, ListOfCategory.Categories[i].categoryName);
                comboBox_CategoryNames.Items.Add(ListOfCategory.Categories[i].categoryName);
            }
        }
        private void btn_Filter_Click(object sender, EventArgs e)
        {         
            List<string> filter = new List<string>();
            for (int i = 0; i < ListOfCategory.Categories.Count; i++)
            {
                filter.Add(ListOfCategory.Categories[i].categoryName.ToString());
            }
            comboBox_Filter.Enabled = true;            
            comboBox_Filter.DataSource = filter;
            comboBox_Filter.SelectedIndex = -1;
        }
        private void comboBox_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_Filter.SelectedIndex == -1)
            {
                showProduct(true);
            }
            else
            {
                showProduct(false);
            }
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            if (tBox_CategoryNameInputted.Text != "")
            {
                bool categoryAdded = false;
                foreach (Category category in ListOfCategory.Categories)
                {
                    if (category.categoryName == tBox_CategoryNameInputted.Text)
                    {
                        categoryAdded = true;
                    }
                }
                if (categoryAdded == true)
                {
                    MessageBox.Show("This Category Has Been Added!");
                }
                else
                {
                    if (ListOfCategory.IsThereAnySimilarCategory(tBox_CategoryNameInputted.Text) == true)
                    {
                        ListOfCategory.MakingCategory(tBox_CategoryNameInputted.Text);
                    }
                }
                tBox_CategoryNameInputted.Clear();
            }
            else
            {
                MessageBox.Show("What Do You Want To Add?");
            }
            showCategories();
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (tBox_CategoryNameInputted.Text != "")
            {
                ListOfCategory.RemoveACategory(tBox_CategoryNameInputted.Text);
                ListOfProduct.RemoveProductByCategoryName(tBox_CategoryNameInputted.Text);
                tBox_CategoryNameInputted.Clear();

            }
            else 
            {
                MessageBox.Show("Which One Do You Want To Remove?");
            }
            showCategories();
            showProduct(true);
        }

        private void dgv_CategoryIDs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgrv = dgv_CategoryIDs.CurrentRow;
            tBox_CategoryNameInputted.Text = dgrv.Cells[1].Value.ToString();
        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            if (tBox_ProductName.Text == "" || tBox_ProductPrice.Text == "" || tBox_ProductStock.Text == "" || comboBox_CategoryNames.SelectedItem == null)
            {
                MessageBox.Show("Please Fill All The Data Needed");
            }
            else
            {
                ListOfProduct.Products.Add(new Product(tBox_ProductName.Text, tBox_ProductPrice.Text, tBox_ProductStock.Text, ListOfCategory.InputTheSameCategory(comboBox_CategoryNames.SelectedItem.ToString()))); 
                tBox_ProductName.Clear();
                tBox_ProductPrice.Clear();
                tBox_ProductStock.Clear();
                comboBox_CategoryNames.SelectedItem = null;
            }
            showProduct(true);
        }

        private void tBox_ProductPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ketemu di internet caranya supaya only number
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void tBox_ProductStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ketemu di internet caranya supaya only number
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void dgv_ListOfProductOnStore_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvr = dgv_ListOfProductOnStore.CurrentRow;
            tBox_ProductName.Text = dgvr.Cells[1].Value.ToString();
            tBox_ProductPrice.Text = dgvr.Cells[2].Value.ToString();
            tBox_ProductStock.Text = dgvr.Cells[3].Value.ToString();
            comboBox_CategoryNames.Text = ListOfCategory.FindCategoryName(dgvr.Cells[4].Value.ToString());
        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dgv_ListOfProductOnStore.CurrentRow;
            if (dgvr.Cells != null && tBox_ProductName.Text != "" && tBox_ProductPrice.Text != "" && tBox_ProductStock.Text != "")
            {
                int index = dgvr.Index;
                for (int i = 0; i < ListOfProduct.Products.Count; i++)
                {
                    if (ListOfProduct.Products[i].productID == dgvr.Cells[0].Value.ToString())
                    {
                        index = i; break;
                    }
                }
                if (tBox_ProductStock.Text == "0")
                {
                    ListOfProduct.Products.RemoveAt(index);
                }
                else
                {
                    ListOfProduct.Products.RemoveAt(index);
                    ListOfProduct.Products.Insert(index, new Product(tBox_ProductName.Text, tBox_ProductPrice.Text, tBox_ProductStock.Text, ListOfCategory.InputTheSameCategory(comboBox_CategoryNames.SelectedItem.ToString())));
                }
            }
            else
            {
                MessageBox.Show("Please Input Correctly Before Editing");
            }
            tBox_ProductName.Clear();
            tBox_ProductPrice.Clear();
            tBox_ProductStock.Clear();
            comboBox_CategoryNames.SelectedItem = null;
            showProduct(true);
        }

        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dgv_ListOfProductOnStore.CurrentRow;
            if (dgvr.Cells != null && tBox_ProductName.Text != "" && tBox_ProductPrice.Text != "" && tBox_ProductStock.Text != "")
            {
                int index = dgvr.Index;
                for (int i = 0; i < ListOfProduct.Products.Count; i++)
                {
                    if (ListOfProduct.Products[i].productID == dgvr.Cells[0].Value.ToString())
                    {
                        index = i; break;
                    }
                }
                ListOfProduct.Products.RemoveAt(index);              
            }
            else
            {
                MessageBox.Show("Please Select The Product You Wanted to Delete");
            }
            tBox_ProductName.Clear();
            tBox_ProductPrice.Clear();
            tBox_ProductStock.Clear();
            comboBox_CategoryNames.SelectedItem = null;
            showProduct(true);
        }
    }
}
