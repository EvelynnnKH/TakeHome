﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_05_TakeHome_FashionStock
{
    internal class Product
    {
        public string productID;
        public string productName;
        public string productPrice;
        public string productStock;
        public Category productCategory;

        public Product(string productName, string productPrice, string productStock, Category productCategory)
        {
            this.productPrice = productPrice;          
            this.productName = productName;
            this.productStock = productStock;
            this.productCategory = productCategory;
            if (this.productID == null)
            {
                makinProductID(productName);
            }
        }
        public void makinProductID(string productName)
        {
            string alphabetID = productName.Substring(0, 1).ToUpper();
            List<string> listTheSameIDCode = new List<string>();
            int counter = 1;
            bool sudahAda = false;
            for (int i = 0;  i < ListOfProduct.Products.Count; i++)
            {
                if(ListOfProduct.Products[i].productID.Substring(0, 1) == alphabetID)
                {
                    sudahAda = true;
                    break;
                }
            }
            if (ListOfProduct.Products.Count == 0 || sudahAda == false)
            {
                productID = alphabetID + "00" + 1;
            }
            else
            {
                for (int i = 0; i < ListOfProduct.Products.Count; i++)
                {
                    if (ListOfProduct.Products[i].productID.Substring(0, 1) == alphabetID)
                    {
                        listTheSameIDCode.Add(ListOfProduct.Products[i].productID.ToString());
                    }
                }             
                int angkaDiCari = Convert.ToInt32(listTheSameIDCode[listTheSameIDCode.Count - 1].Substring(counter, listTheSameIDCode[listTheSameIDCode.Count - 1].Length - counter));
                productID = alphabetID + string.Format("{0:000}", angkaDiCari + 1);
            }
        }
    }
}
