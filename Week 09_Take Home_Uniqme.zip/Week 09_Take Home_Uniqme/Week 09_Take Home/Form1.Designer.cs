﻿namespace Week_09_Take_Home
{
    partial class for_UNIQME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_Nota = new System.Windows.Forms.DataGridView();
            this.label_SubTotal = new System.Windows.Forms.Label();
            this.tBox_SubTotal = new System.Windows.Forms.TextBox();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.tBox_Total = new System.Windows.Forms.TextBox();
            this.label_Total = new System.Windows.Forms.Label();
            this.menuStrip_MainMenu = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_TShirt = new System.Windows.Forms.Panel();
            this.btn_AddShirtHitam = new System.Windows.Forms.Button();
            this.btn_AddShirtCream = new System.Windows.Forms.Button();
            this.btn_AddShirtBiru = new System.Windows.Forms.Button();
            this.label_hargaShirtHitam = new System.Windows.Forms.Label();
            this.label_hargaShirtCream = new System.Windows.Forms.Label();
            this.label_hargaShirtBiru = new System.Windows.Forms.Label();
            this.label_namaShirtHitam = new System.Windows.Forms.Label();
            this.label_namaShirtCream = new System.Windows.Forms.Label();
            this.label_namaShirtBiru = new System.Windows.Forms.Label();
            this.pictureBox_shirtHitam = new System.Windows.Forms.PictureBox();
            this.pictureBox_shirtCream = new System.Windows.Forms.PictureBox();
            this.pictureBox_shirtBiru = new System.Windows.Forms.PictureBox();
            this.panel_T = new System.Windows.Forms.Panel();
            this.btn_AddTHitam = new System.Windows.Forms.Button();
            this.btn_AddTCream = new System.Windows.Forms.Button();
            this.btn_AddTBiru = new System.Windows.Forms.Button();
            this.label_hargaTHitam = new System.Windows.Forms.Label();
            this.label_hargaTCream = new System.Windows.Forms.Label();
            this.label_hargaTBiru = new System.Windows.Forms.Label();
            this.label_namaTHitam = new System.Windows.Forms.Label();
            this.label_namaTCream = new System.Windows.Forms.Label();
            this.label_namaTBiru = new System.Windows.Forms.Label();
            this.pictureBox_THitam = new System.Windows.Forms.PictureBox();
            this.pictureBox_TCream = new System.Windows.Forms.PictureBox();
            this.pictureBox_TBiru = new System.Windows.Forms.PictureBox();
            this.panel_LongPants = new System.Windows.Forms.Panel();
            this.btn_AddLongStretch = new System.Windows.Forms.Button();
            this.btn_AddLongPilgrim = new System.Windows.Forms.Button();
            this.btn_AddLongHeadGear = new System.Windows.Forms.Button();
            this.label_hargaLongStretch = new System.Windows.Forms.Label();
            this.label_hargaLongPilgrim = new System.Windows.Forms.Label();
            this.label_hargaLongHeadGear = new System.Windows.Forms.Label();
            this.label_namaLongStretch = new System.Windows.Forms.Label();
            this.label_namaLongPilgrim = new System.Windows.Forms.Label();
            this.label_namaLongHeadGear = new System.Windows.Forms.Label();
            this.pictureBox_longStretch = new System.Windows.Forms.PictureBox();
            this.pictureBox_longPilgrim = new System.Windows.Forms.PictureBox();
            this.pictureBox_longHeadGear = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_pantsOrange = new System.Windows.Forms.Button();
            this.btn_pantsSLVRS = new System.Windows.Forms.Button();
            this.btn_pantsAZA = new System.Windows.Forms.Button();
            this.label_hargaPantsOrange = new System.Windows.Forms.Label();
            this.label_hargaSLVRSPants = new System.Windows.Forms.Label();
            this.label_hargaAzaPants = new System.Windows.Forms.Label();
            this.label_namaPantsOrange = new System.Windows.Forms.Label();
            this.label_namaPantsSLVRS = new System.Windows.Forms.Label();
            this.label_namaPantsAza = new System.Windows.Forms.Label();
            this.pictureBox_OrangePants = new System.Windows.Forms.PictureBox();
            this.pictureBox_pantsSLVRS = new System.Windows.Forms.PictureBox();
            this.pictureBox_pantsAza = new System.Windows.Forms.PictureBox();
            this.panel_Accessories = new System.Windows.Forms.Panel();
            this.btn_AddRingDiamond = new System.Windows.Forms.Button();
            this.btn_AddNecklace = new System.Windows.Forms.Button();
            this.btn_AddRing = new System.Windows.Forms.Button();
            this.label_hargaRingDiamond = new System.Windows.Forms.Label();
            this.label_hargaNecklace = new System.Windows.Forms.Label();
            this.label_hargaRing = new System.Windows.Forms.Label();
            this.label_namaRingDiamond = new System.Windows.Forms.Label();
            this.label_namaNecklace = new System.Windows.Forms.Label();
            this.label_namaRing = new System.Windows.Forms.Label();
            this.pictureBox_RingDiamond = new System.Windows.Forms.PictureBox();
            this.pictureBox_necklace = new System.Windows.Forms.PictureBox();
            this.pictureBox_ring = new System.Windows.Forms.PictureBox();
            this.panel_Shoes = new System.Windows.Forms.Panel();
            this.btn_AddShoeLambard = new System.Windows.Forms.Button();
            this.btn_AddShoeYonex = new System.Windows.Forms.Button();
            this.btn_AddShoeAurora = new System.Windows.Forms.Button();
            this.label_hargaShoeLambard = new System.Windows.Forms.Label();
            this.label_hargaShoeYonex = new System.Windows.Forms.Label();
            this.label_hargaShoeAurora = new System.Windows.Forms.Label();
            this.label_namaShoeLambard = new System.Windows.Forms.Label();
            this.label_namaShoeYonex = new System.Windows.Forms.Label();
            this.label_namaShoeAurora = new System.Windows.Forms.Label();
            this.pictureBox_shoeLambard = new System.Windows.Forms.PictureBox();
            this.pictureBox_ShoeYonex = new System.Windows.Forms.PictureBox();
            this.pictureBox_shoeAurora = new System.Windows.Forms.PictureBox();
            this.panel_Other = new System.Windows.Forms.Panel();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.tBox_ItemPrice = new System.Windows.Forms.TextBox();
            this.tBox_ItemName = new System.Windows.Forms.TextBox();
            this.label_ItemPrice = new System.Windows.Forms.Label();
            this.label_ItemName = new System.Windows.Forms.Label();
            this.pictureBox_UploadedImage = new System.Windows.Forms.PictureBox();
            this.label_UploadImage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Nota)).BeginInit();
            this.menuStrip_MainMenu.SuspendLayout();
            this.panel_TShirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shirtHitam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shirtCream)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shirtBiru)).BeginInit();
            this.panel_T.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_THitam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_TCream)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_TBiru)).BeginInit();
            this.panel_LongPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longStretch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longPilgrim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longHeadGear)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_OrangePants)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pantsSLVRS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pantsAza)).BeginInit();
            this.panel_Accessories.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RingDiamond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_necklace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ring)).BeginInit();
            this.panel_Shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shoeLambard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ShoeYonex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shoeAurora)).BeginInit();
            this.panel_Other.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UploadedImage)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Nota
            // 
            this.dgv_Nota.AllowUserToAddRows = false;
            this.dgv_Nota.AllowUserToDeleteRows = false;
            this.dgv_Nota.AllowUserToResizeColumns = false;
            this.dgv_Nota.AllowUserToResizeRows = false;
            this.dgv_Nota.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_Nota.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Nota.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Nota.Location = new System.Drawing.Point(581, 31);
            this.dgv_Nota.MultiSelect = false;
            this.dgv_Nota.Name = "dgv_Nota";
            this.dgv_Nota.RowHeadersVisible = false;
            this.dgv_Nota.RowHeadersWidth = 51;
            this.dgv_Nota.RowTemplate.Height = 24;
            this.dgv_Nota.Size = new System.Drawing.Size(336, 285);
            this.dgv_Nota.TabIndex = 1;
            // 
            // label_SubTotal
            // 
            this.label_SubTotal.AutoSize = true;
            this.label_SubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SubTotal.Location = new System.Drawing.Point(577, 328);
            this.label_SubTotal.Name = "label_SubTotal";
            this.label_SubTotal.Size = new System.Drawing.Size(96, 20);
            this.label_SubTotal.TabIndex = 2;
            this.label_SubTotal.Text = "Sub-Total:";
            // 
            // tBox_SubTotal
            // 
            this.tBox_SubTotal.Location = new System.Drawing.Point(679, 328);
            this.tBox_SubTotal.Name = "tBox_SubTotal";
            this.tBox_SubTotal.Size = new System.Drawing.Size(148, 22);
            this.tBox_SubTotal.TabIndex = 3;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(842, 328);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 4;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // tBox_Total
            // 
            this.tBox_Total.Location = new System.Drawing.Point(679, 356);
            this.tBox_Total.Name = "tBox_Total";
            this.tBox_Total.Size = new System.Drawing.Size(148, 22);
            this.tBox_Total.TabIndex = 6;
            // 
            // label_Total
            // 
            this.label_Total.AutoSize = true;
            this.label_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Total.Location = new System.Drawing.Point(616, 356);
            this.label_Total.Name = "label_Total";
            this.label_Total.Size = new System.Drawing.Size(57, 20);
            this.label_Total.TabIndex = 5;
            this.label_Total.Text = "Total:";
            // 
            // menuStrip_MainMenu
            // 
            this.menuStrip_MainMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip_MainMenu.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_MainMenu.Name = "menuStrip_MainMenu";
            this.menuStrip_MainMenu.Size = new System.Drawing.Size(946, 28);
            this.menuStrip_MainMenu.TabIndex = 7;
            this.menuStrip_MainMenu.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.accessoriesToolStripMenuItem1});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem1
            // 
            this.accessoriesToolStripMenuItem1.Name = "accessoriesToolStripMenuItem1";
            this.accessoriesToolStripMenuItem1.Size = new System.Drawing.Size(163, 26);
            this.accessoriesToolStripMenuItem1.Text = "Jewelleries";
            this.accessoriesToolStripMenuItem1.Click += new System.EventHandler(this.accessoriesToolStripMenuItem1_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // panel_TShirt
            // 
            this.panel_TShirt.Controls.Add(this.btn_AddShirtHitam);
            this.panel_TShirt.Controls.Add(this.btn_AddShirtCream);
            this.panel_TShirt.Controls.Add(this.btn_AddShirtBiru);
            this.panel_TShirt.Controls.Add(this.label_hargaShirtHitam);
            this.panel_TShirt.Controls.Add(this.label_hargaShirtCream);
            this.panel_TShirt.Controls.Add(this.label_hargaShirtBiru);
            this.panel_TShirt.Controls.Add(this.label_namaShirtHitam);
            this.panel_TShirt.Controls.Add(this.label_namaShirtCream);
            this.panel_TShirt.Controls.Add(this.label_namaShirtBiru);
            this.panel_TShirt.Controls.Add(this.pictureBox_shirtHitam);
            this.panel_TShirt.Controls.Add(this.pictureBox_shirtCream);
            this.panel_TShirt.Controls.Add(this.pictureBox_shirtBiru);
            this.panel_TShirt.Location = new System.Drawing.Point(12, 31);
            this.panel_TShirt.Name = "panel_TShirt";
            this.panel_TShirt.Size = new System.Drawing.Size(519, 417);
            this.panel_TShirt.TabIndex = 8;
            this.panel_TShirt.Visible = false;
            // 
            // btn_AddShirtHitam
            // 
            this.btn_AddShirtHitam.Location = new System.Drawing.Point(371, 307);
            this.btn_AddShirtHitam.Name = "btn_AddShirtHitam";
            this.btn_AddShirtHitam.Size = new System.Drawing.Size(113, 23);
            this.btn_AddShirtHitam.TabIndex = 11;
            this.btn_AddShirtHitam.Text = "Add to Cart";
            this.btn_AddShirtHitam.UseVisualStyleBackColor = true;
            this.btn_AddShirtHitam.Click += new System.EventHandler(this.btn_AddShirtHitam_Click);
            // 
            // btn_AddShirtCream
            // 
            this.btn_AddShirtCream.Location = new System.Drawing.Point(190, 307);
            this.btn_AddShirtCream.Name = "btn_AddShirtCream";
            this.btn_AddShirtCream.Size = new System.Drawing.Size(113, 23);
            this.btn_AddShirtCream.TabIndex = 10;
            this.btn_AddShirtCream.Text = "Add to Cart";
            this.btn_AddShirtCream.UseVisualStyleBackColor = true;
            this.btn_AddShirtCream.Click += new System.EventHandler(this.btn_AddShirtCream_Click);
            // 
            // btn_AddShirtBiru
            // 
            this.btn_AddShirtBiru.Location = new System.Drawing.Point(6, 307);
            this.btn_AddShirtBiru.Name = "btn_AddShirtBiru";
            this.btn_AddShirtBiru.Size = new System.Drawing.Size(113, 23);
            this.btn_AddShirtBiru.TabIndex = 9;
            this.btn_AddShirtBiru.Text = "Add to Cart";
            this.btn_AddShirtBiru.UseVisualStyleBackColor = true;
            this.btn_AddShirtBiru.Click += new System.EventHandler(this.btn_AddShirtBiru_Click);
            // 
            // label_hargaShirtHitam
            // 
            this.label_hargaShirtHitam.AutoSize = true;
            this.label_hargaShirtHitam.Location = new System.Drawing.Point(368, 285);
            this.label_hargaShirtHitam.Name = "label_hargaShirtHitam";
            this.label_hargaShirtHitam.Size = new System.Drawing.Size(97, 16);
            this.label_hargaShirtHitam.TabIndex = 8;
            this.label_hargaShirtHitam.Text = "Rp. 130.000,00-";
            // 
            // label_hargaShirtCream
            // 
            this.label_hargaShirtCream.AutoSize = true;
            this.label_hargaShirtCream.Location = new System.Drawing.Point(187, 285);
            this.label_hargaShirtCream.Name = "label_hargaShirtCream";
            this.label_hargaShirtCream.Size = new System.Drawing.Size(97, 16);
            this.label_hargaShirtCream.TabIndex = 7;
            this.label_hargaShirtCream.Text = "Rp. 150.000,00-";
            // 
            // label_hargaShirtBiru
            // 
            this.label_hargaShirtBiru.AutoSize = true;
            this.label_hargaShirtBiru.Location = new System.Drawing.Point(3, 285);
            this.label_hargaShirtBiru.Name = "label_hargaShirtBiru";
            this.label_hargaShirtBiru.Size = new System.Drawing.Size(97, 16);
            this.label_hargaShirtBiru.TabIndex = 6;
            this.label_hargaShirtBiru.Text = "Rp. 120.000,00-";
            // 
            // label_namaShirtHitam
            // 
            this.label_namaShirtHitam.AutoSize = true;
            this.label_namaShirtHitam.Location = new System.Drawing.Point(368, 259);
            this.label_namaShirtHitam.Name = "label_namaShirtHitam";
            this.label_namaShirtHitam.Size = new System.Drawing.Size(71, 16);
            this.label_namaShirtHitam.TabIndex = 5;
            this.label_namaShirtHitam.Text = "Shirt Hitam";
            // 
            // label_namaShirtCream
            // 
            this.label_namaShirtCream.AutoSize = true;
            this.label_namaShirtCream.Location = new System.Drawing.Point(187, 259);
            this.label_namaShirtCream.Name = "label_namaShirtCream";
            this.label_namaShirtCream.Size = new System.Drawing.Size(76, 16);
            this.label_namaShirtCream.TabIndex = 4;
            this.label_namaShirtCream.Text = "Shirt Cream";
            // 
            // label_namaShirtBiru
            // 
            this.label_namaShirtBiru.AutoSize = true;
            this.label_namaShirtBiru.Location = new System.Drawing.Point(3, 259);
            this.label_namaShirtBiru.Name = "label_namaShirtBiru";
            this.label_namaShirtBiru.Size = new System.Drawing.Size(59, 16);
            this.label_namaShirtBiru.TabIndex = 3;
            this.label_namaShirtBiru.Text = "Shirt Biru";
            // 
            // pictureBox_shirtHitam
            // 
            this.pictureBox_shirtHitam.Image = global::Week_09_Take_Home.Properties.Resources.T_ShirtHitam;
            this.pictureBox_shirtHitam.Location = new System.Drawing.Point(371, 23);
            this.pictureBox_shirtHitam.Name = "pictureBox_shirtHitam";
            this.pictureBox_shirtHitam.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_shirtHitam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_shirtHitam.TabIndex = 2;
            this.pictureBox_shirtHitam.TabStop = false;
            // 
            // pictureBox_shirtCream
            // 
            this.pictureBox_shirtCream.Image = global::Week_09_Take_Home.Properties.Resources.T_ShirtCream;
            this.pictureBox_shirtCream.Location = new System.Drawing.Point(190, 23);
            this.pictureBox_shirtCream.Name = "pictureBox_shirtCream";
            this.pictureBox_shirtCream.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_shirtCream.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_shirtCream.TabIndex = 1;
            this.pictureBox_shirtCream.TabStop = false;
            // 
            // pictureBox_shirtBiru
            // 
            this.pictureBox_shirtBiru.Image = global::Week_09_Take_Home.Properties.Resources.T_ShirtBiru;
            this.pictureBox_shirtBiru.Location = new System.Drawing.Point(3, 23);
            this.pictureBox_shirtBiru.Name = "pictureBox_shirtBiru";
            this.pictureBox_shirtBiru.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_shirtBiru.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_shirtBiru.TabIndex = 0;
            this.pictureBox_shirtBiru.TabStop = false;
            // 
            // panel_T
            // 
            this.panel_T.Controls.Add(this.btn_AddTHitam);
            this.panel_T.Controls.Add(this.btn_AddTCream);
            this.panel_T.Controls.Add(this.btn_AddTBiru);
            this.panel_T.Controls.Add(this.label_hargaTHitam);
            this.panel_T.Controls.Add(this.label_hargaTCream);
            this.panel_T.Controls.Add(this.label_hargaTBiru);
            this.panel_T.Controls.Add(this.label_namaTHitam);
            this.panel_T.Controls.Add(this.label_namaTCream);
            this.panel_T.Controls.Add(this.label_namaTBiru);
            this.panel_T.Controls.Add(this.pictureBox_THitam);
            this.panel_T.Controls.Add(this.pictureBox_TCream);
            this.panel_T.Controls.Add(this.pictureBox_TBiru);
            this.panel_T.Location = new System.Drawing.Point(11, 32);
            this.panel_T.Name = "panel_T";
            this.panel_T.Size = new System.Drawing.Size(519, 417);
            this.panel_T.TabIndex = 12;
            this.panel_T.Visible = false;
            // 
            // btn_AddTHitam
            // 
            this.btn_AddTHitam.Location = new System.Drawing.Point(371, 307);
            this.btn_AddTHitam.Name = "btn_AddTHitam";
            this.btn_AddTHitam.Size = new System.Drawing.Size(113, 23);
            this.btn_AddTHitam.TabIndex = 11;
            this.btn_AddTHitam.Text = "Add to Cart";
            this.btn_AddTHitam.UseVisualStyleBackColor = true;
            this.btn_AddTHitam.Click += new System.EventHandler(this.btn_AddTHitam_Click);
            // 
            // btn_AddTCream
            // 
            this.btn_AddTCream.Location = new System.Drawing.Point(190, 307);
            this.btn_AddTCream.Name = "btn_AddTCream";
            this.btn_AddTCream.Size = new System.Drawing.Size(113, 23);
            this.btn_AddTCream.TabIndex = 10;
            this.btn_AddTCream.Text = "Add to Cart";
            this.btn_AddTCream.UseVisualStyleBackColor = true;
            this.btn_AddTCream.Click += new System.EventHandler(this.btn_AddTCream_Click);
            // 
            // btn_AddTBiru
            // 
            this.btn_AddTBiru.Location = new System.Drawing.Point(6, 307);
            this.btn_AddTBiru.Name = "btn_AddTBiru";
            this.btn_AddTBiru.Size = new System.Drawing.Size(113, 23);
            this.btn_AddTBiru.TabIndex = 9;
            this.btn_AddTBiru.Text = "Add to Cart";
            this.btn_AddTBiru.UseVisualStyleBackColor = true;
            this.btn_AddTBiru.Click += new System.EventHandler(this.btn_AddTBiru_Click);
            // 
            // label_hargaTHitam
            // 
            this.label_hargaTHitam.AutoSize = true;
            this.label_hargaTHitam.Location = new System.Drawing.Point(368, 285);
            this.label_hargaTHitam.Name = "label_hargaTHitam";
            this.label_hargaTHitam.Size = new System.Drawing.Size(97, 16);
            this.label_hargaTHitam.TabIndex = 8;
            this.label_hargaTHitam.Text = "Rp. 150.000,00-";
            // 
            // label_hargaTCream
            // 
            this.label_hargaTCream.AutoSize = true;
            this.label_hargaTCream.Location = new System.Drawing.Point(187, 285);
            this.label_hargaTCream.Name = "label_hargaTCream";
            this.label_hargaTCream.Size = new System.Drawing.Size(97, 16);
            this.label_hargaTCream.TabIndex = 7;
            this.label_hargaTCream.Text = "Rp. 170.000,00-";
            // 
            // label_hargaTBiru
            // 
            this.label_hargaTBiru.AutoSize = true;
            this.label_hargaTBiru.Location = new System.Drawing.Point(3, 285);
            this.label_hargaTBiru.Name = "label_hargaTBiru";
            this.label_hargaTBiru.Size = new System.Drawing.Size(97, 16);
            this.label_hargaTBiru.TabIndex = 6;
            this.label_hargaTBiru.Text = "Rp. 140.000,00-";
            // 
            // label_namaTHitam
            // 
            this.label_namaTHitam.AutoSize = true;
            this.label_namaTHitam.Location = new System.Drawing.Point(368, 259);
            this.label_namaTHitam.Name = "label_namaTHitam";
            this.label_namaTHitam.Size = new System.Drawing.Size(84, 16);
            this.label_namaTHitam.TabIndex = 5;
            this.label_namaTHitam.Text = "T-Shirt Hitam";
            // 
            // label_namaTCream
            // 
            this.label_namaTCream.AutoSize = true;
            this.label_namaTCream.Location = new System.Drawing.Point(187, 259);
            this.label_namaTCream.Name = "label_namaTCream";
            this.label_namaTCream.Size = new System.Drawing.Size(89, 16);
            this.label_namaTCream.TabIndex = 4;
            this.label_namaTCream.Text = "T-Shirt Cream";
            // 
            // label_namaTBiru
            // 
            this.label_namaTBiru.AutoSize = true;
            this.label_namaTBiru.Location = new System.Drawing.Point(3, 259);
            this.label_namaTBiru.Name = "label_namaTBiru";
            this.label_namaTBiru.Size = new System.Drawing.Size(72, 16);
            this.label_namaTBiru.TabIndex = 3;
            this.label_namaTBiru.Text = "T-Shirt Biru";
            // 
            // pictureBox_THitam
            // 
            this.pictureBox_THitam.Image = global::Week_09_Take_Home.Properties.Resources.shirt_ireng;
            this.pictureBox_THitam.Location = new System.Drawing.Point(371, 23);
            this.pictureBox_THitam.Name = "pictureBox_THitam";
            this.pictureBox_THitam.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_THitam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_THitam.TabIndex = 2;
            this.pictureBox_THitam.TabStop = false;
            // 
            // pictureBox_TCream
            // 
            this.pictureBox_TCream.Image = global::Week_09_Take_Home.Properties.Resources.shirt_cream;
            this.pictureBox_TCream.Location = new System.Drawing.Point(190, 23);
            this.pictureBox_TCream.Name = "pictureBox_TCream";
            this.pictureBox_TCream.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_TCream.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_TCream.TabIndex = 1;
            this.pictureBox_TCream.TabStop = false;
            // 
            // pictureBox_TBiru
            // 
            this.pictureBox_TBiru.Image = global::Week_09_Take_Home.Properties.Resources.shirt_biru;
            this.pictureBox_TBiru.Location = new System.Drawing.Point(3, 23);
            this.pictureBox_TBiru.Name = "pictureBox_TBiru";
            this.pictureBox_TBiru.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_TBiru.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_TBiru.TabIndex = 0;
            this.pictureBox_TBiru.TabStop = false;
            // 
            // panel_LongPants
            // 
            this.panel_LongPants.Controls.Add(this.btn_AddLongStretch);
            this.panel_LongPants.Controls.Add(this.btn_AddLongPilgrim);
            this.panel_LongPants.Controls.Add(this.btn_AddLongHeadGear);
            this.panel_LongPants.Controls.Add(this.label_hargaLongStretch);
            this.panel_LongPants.Controls.Add(this.label_hargaLongPilgrim);
            this.panel_LongPants.Controls.Add(this.label_hargaLongHeadGear);
            this.panel_LongPants.Controls.Add(this.label_namaLongStretch);
            this.panel_LongPants.Controls.Add(this.label_namaLongPilgrim);
            this.panel_LongPants.Controls.Add(this.label_namaLongHeadGear);
            this.panel_LongPants.Controls.Add(this.pictureBox_longStretch);
            this.panel_LongPants.Controls.Add(this.pictureBox_longPilgrim);
            this.panel_LongPants.Controls.Add(this.pictureBox_longHeadGear);
            this.panel_LongPants.Location = new System.Drawing.Point(12, 31);
            this.panel_LongPants.Name = "panel_LongPants";
            this.panel_LongPants.Size = new System.Drawing.Size(519, 417);
            this.panel_LongPants.TabIndex = 14;
            this.panel_LongPants.Visible = false;
            // 
            // btn_AddLongStretch
            // 
            this.btn_AddLongStretch.Location = new System.Drawing.Point(371, 307);
            this.btn_AddLongStretch.Name = "btn_AddLongStretch";
            this.btn_AddLongStretch.Size = new System.Drawing.Size(113, 23);
            this.btn_AddLongStretch.TabIndex = 11;
            this.btn_AddLongStretch.Text = "Add to Cart";
            this.btn_AddLongStretch.UseVisualStyleBackColor = true;
            this.btn_AddLongStretch.Click += new System.EventHandler(this.btn_AddLongStretch_Click);
            // 
            // btn_AddLongPilgrim
            // 
            this.btn_AddLongPilgrim.Location = new System.Drawing.Point(190, 307);
            this.btn_AddLongPilgrim.Name = "btn_AddLongPilgrim";
            this.btn_AddLongPilgrim.Size = new System.Drawing.Size(113, 23);
            this.btn_AddLongPilgrim.TabIndex = 10;
            this.btn_AddLongPilgrim.Text = "Add to Cart";
            this.btn_AddLongPilgrim.UseVisualStyleBackColor = true;
            this.btn_AddLongPilgrim.Click += new System.EventHandler(this.btn_AddLongPilgrim_Click);
            // 
            // btn_AddLongHeadGear
            // 
            this.btn_AddLongHeadGear.Location = new System.Drawing.Point(6, 307);
            this.btn_AddLongHeadGear.Name = "btn_AddLongHeadGear";
            this.btn_AddLongHeadGear.Size = new System.Drawing.Size(113, 23);
            this.btn_AddLongHeadGear.TabIndex = 9;
            this.btn_AddLongHeadGear.Text = "Add to Cart";
            this.btn_AddLongHeadGear.UseVisualStyleBackColor = true;
            this.btn_AddLongHeadGear.Click += new System.EventHandler(this.btn_AddLongHeadGear_Click);
            // 
            // label_hargaLongStretch
            // 
            this.label_hargaLongStretch.AutoSize = true;
            this.label_hargaLongStretch.Location = new System.Drawing.Point(368, 285);
            this.label_hargaLongStretch.Name = "label_hargaLongStretch";
            this.label_hargaLongStretch.Size = new System.Drawing.Size(97, 16);
            this.label_hargaLongStretch.TabIndex = 8;
            this.label_hargaLongStretch.Text = "Rp. 500.000,00-";
            // 
            // label_hargaLongPilgrim
            // 
            this.label_hargaLongPilgrim.AutoSize = true;
            this.label_hargaLongPilgrim.Location = new System.Drawing.Point(187, 285);
            this.label_hargaLongPilgrim.Name = "label_hargaLongPilgrim";
            this.label_hargaLongPilgrim.Size = new System.Drawing.Size(97, 16);
            this.label_hargaLongPilgrim.TabIndex = 7;
            this.label_hargaLongPilgrim.Text = "Rp. 365.000,00-";
            // 
            // label_hargaLongHeadGear
            // 
            this.label_hargaLongHeadGear.AutoSize = true;
            this.label_hargaLongHeadGear.Location = new System.Drawing.Point(3, 285);
            this.label_hargaLongHeadGear.Name = "label_hargaLongHeadGear";
            this.label_hargaLongHeadGear.Size = new System.Drawing.Size(97, 16);
            this.label_hargaLongHeadGear.TabIndex = 6;
            this.label_hargaLongHeadGear.Text = "Rp. 267.000,00-";
            // 
            // label_namaLongStretch
            // 
            this.label_namaLongStretch.AutoSize = true;
            this.label_namaLongStretch.Location = new System.Drawing.Point(368, 259);
            this.label_namaLongStretch.Name = "label_namaLongStretch";
            this.label_namaLongStretch.Size = new System.Drawing.Size(120, 16);
            this.label_namaLongStretch.TabIndex = 5;
            this.label_namaLongStretch.Text = "Stretch Dock Pants";
            // 
            // label_namaLongPilgrim
            // 
            this.label_namaLongPilgrim.AutoSize = true;
            this.label_namaLongPilgrim.Location = new System.Drawing.Point(187, 259);
            this.label_namaLongPilgrim.Name = "label_namaLongPilgrim";
            this.label_namaLongPilgrim.Size = new System.Drawing.Size(118, 16);
            this.label_namaLongPilgrim.TabIndex = 4;
            this.label_namaLongPilgrim.Text = "Pilgrim Long Pants";
            // 
            // label_namaLongHeadGear
            // 
            this.label_namaLongHeadGear.AutoSize = true;
            this.label_namaLongHeadGear.Location = new System.Drawing.Point(3, 259);
            this.label_namaLongHeadGear.Name = "label_namaLongHeadGear";
            this.label_namaLongHeadGear.Size = new System.Drawing.Size(111, 16);
            this.label_namaLongHeadGear.TabIndex = 3;
            this.label_namaLongHeadGear.Text = "Head Gear Pants";
            // 
            // pictureBox_longStretch
            // 
            this.pictureBox_longStretch.Image = global::Week_09_Take_Home.Properties.Resources.Stretch_Dock_Pants;
            this.pictureBox_longStretch.Location = new System.Drawing.Point(371, 23);
            this.pictureBox_longStretch.Name = "pictureBox_longStretch";
            this.pictureBox_longStretch.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_longStretch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_longStretch.TabIndex = 2;
            this.pictureBox_longStretch.TabStop = false;
            // 
            // pictureBox_longPilgrim
            // 
            this.pictureBox_longPilgrim.Image = global::Week_09_Take_Home.Properties.Resources.pilgrim_pants;
            this.pictureBox_longPilgrim.Location = new System.Drawing.Point(190, 23);
            this.pictureBox_longPilgrim.Name = "pictureBox_longPilgrim";
            this.pictureBox_longPilgrim.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_longPilgrim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_longPilgrim.TabIndex = 1;
            this.pictureBox_longPilgrim.TabStop = false;
            // 
            // pictureBox_longHeadGear
            // 
            this.pictureBox_longHeadGear.Image = global::Week_09_Take_Home.Properties.Resources.heatgear_pants__859_000_;
            this.pictureBox_longHeadGear.Location = new System.Drawing.Point(3, 23);
            this.pictureBox_longHeadGear.Name = "pictureBox_longHeadGear";
            this.pictureBox_longHeadGear.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_longHeadGear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_longHeadGear.TabIndex = 0;
            this.pictureBox_longHeadGear.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_pantsOrange);
            this.panel_pants.Controls.Add(this.btn_pantsSLVRS);
            this.panel_pants.Controls.Add(this.btn_pantsAZA);
            this.panel_pants.Controls.Add(this.label_hargaPantsOrange);
            this.panel_pants.Controls.Add(this.label_hargaSLVRSPants);
            this.panel_pants.Controls.Add(this.label_hargaAzaPants);
            this.panel_pants.Controls.Add(this.label_namaPantsOrange);
            this.panel_pants.Controls.Add(this.label_namaPantsSLVRS);
            this.panel_pants.Controls.Add(this.label_namaPantsAza);
            this.panel_pants.Controls.Add(this.pictureBox_OrangePants);
            this.panel_pants.Controls.Add(this.pictureBox_pantsSLVRS);
            this.panel_pants.Controls.Add(this.pictureBox_pantsAza);
            this.panel_pants.Location = new System.Drawing.Point(11, 32);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(519, 417);
            this.panel_pants.TabIndex = 13;
            this.panel_pants.Visible = false;
            // 
            // btn_pantsOrange
            // 
            this.btn_pantsOrange.Location = new System.Drawing.Point(371, 307);
            this.btn_pantsOrange.Name = "btn_pantsOrange";
            this.btn_pantsOrange.Size = new System.Drawing.Size(113, 23);
            this.btn_pantsOrange.TabIndex = 11;
            this.btn_pantsOrange.Text = "Add to Cart";
            this.btn_pantsOrange.UseVisualStyleBackColor = true;
            this.btn_pantsOrange.Click += new System.EventHandler(this.btn_pantsOrange_Click);
            // 
            // btn_pantsSLVRS
            // 
            this.btn_pantsSLVRS.Location = new System.Drawing.Point(190, 307);
            this.btn_pantsSLVRS.Name = "btn_pantsSLVRS";
            this.btn_pantsSLVRS.Size = new System.Drawing.Size(113, 23);
            this.btn_pantsSLVRS.TabIndex = 10;
            this.btn_pantsSLVRS.Text = "Add to Cart";
            this.btn_pantsSLVRS.UseVisualStyleBackColor = true;
            this.btn_pantsSLVRS.Click += new System.EventHandler(this.btn_pantsSLVRS_Click);
            // 
            // btn_pantsAZA
            // 
            this.btn_pantsAZA.Location = new System.Drawing.Point(6, 307);
            this.btn_pantsAZA.Name = "btn_pantsAZA";
            this.btn_pantsAZA.Size = new System.Drawing.Size(113, 23);
            this.btn_pantsAZA.TabIndex = 9;
            this.btn_pantsAZA.Text = "Add to Cart";
            this.btn_pantsAZA.UseVisualStyleBackColor = true;
            this.btn_pantsAZA.Click += new System.EventHandler(this.btn_pantsAZA_Click);
            // 
            // label_hargaPantsOrange
            // 
            this.label_hargaPantsOrange.AutoSize = true;
            this.label_hargaPantsOrange.Location = new System.Drawing.Point(368, 285);
            this.label_hargaPantsOrange.Name = "label_hargaPantsOrange";
            this.label_hargaPantsOrange.Size = new System.Drawing.Size(97, 16);
            this.label_hargaPantsOrange.TabIndex = 8;
            this.label_hargaPantsOrange.Text = "Rp. 100.000,00-";
            // 
            // label_hargaSLVRSPants
            // 
            this.label_hargaSLVRSPants.AutoSize = true;
            this.label_hargaSLVRSPants.Location = new System.Drawing.Point(187, 285);
            this.label_hargaSLVRSPants.Name = "label_hargaSLVRSPants";
            this.label_hargaSLVRSPants.Size = new System.Drawing.Size(90, 16);
            this.label_hargaSLVRSPants.TabIndex = 7;
            this.label_hargaSLVRSPants.Text = "Rp. 79.000,00-";
            // 
            // label_hargaAzaPants
            // 
            this.label_hargaAzaPants.AutoSize = true;
            this.label_hargaAzaPants.Location = new System.Drawing.Point(3, 285);
            this.label_hargaAzaPants.Name = "label_hargaAzaPants";
            this.label_hargaAzaPants.Size = new System.Drawing.Size(90, 16);
            this.label_hargaAzaPants.TabIndex = 6;
            this.label_hargaAzaPants.Text = "Rp. 90.000,00-";
            // 
            // label_namaPantsOrange
            // 
            this.label_namaPantsOrange.AutoSize = true;
            this.label_namaPantsOrange.Location = new System.Drawing.Point(368, 259);
            this.label_namaPantsOrange.Name = "label_namaPantsOrange";
            this.label_namaPantsOrange.Size = new System.Drawing.Size(89, 16);
            this.label_namaPantsOrange.TabIndex = 5;
            this.label_namaPantsOrange.Text = "Orange Pants";
            // 
            // label_namaPantsSLVRS
            // 
            this.label_namaPantsSLVRS.AutoSize = true;
            this.label_namaPantsSLVRS.Location = new System.Drawing.Point(187, 259);
            this.label_namaPantsSLVRS.Name = "label_namaPantsSLVRS";
            this.label_namaPantsSLVRS.Size = new System.Drawing.Size(121, 16);
            this.label_namaPantsSLVRS.TabIndex = 4;
            this.label_namaPantsSLVRS.Text = "SLVRS Short pants";
            // 
            // label_namaPantsAza
            // 
            this.label_namaPantsAza.AutoSize = true;
            this.label_namaPantsAza.Location = new System.Drawing.Point(3, 259);
            this.label_namaPantsAza.Name = "label_namaPantsAza";
            this.label_namaPantsAza.Size = new System.Drawing.Size(104, 16);
            this.label_namaPantsAza.TabIndex = 3;
            this.label_namaPantsAza.Text = "AZA Short Pants";
            // 
            // pictureBox_OrangePants
            // 
            this.pictureBox_OrangePants.Image = global::Week_09_Take_Home.Properties.Resources.orange_pants;
            this.pictureBox_OrangePants.Location = new System.Drawing.Point(371, 23);
            this.pictureBox_OrangePants.Name = "pictureBox_OrangePants";
            this.pictureBox_OrangePants.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_OrangePants.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_OrangePants.TabIndex = 2;
            this.pictureBox_OrangePants.TabStop = false;
            // 
            // pictureBox_pantsSLVRS
            // 
            this.pictureBox_pantsSLVRS.Image = global::Week_09_Take_Home.Properties.Resources.SLVRS_Short_pants__78_900_;
            this.pictureBox_pantsSLVRS.Location = new System.Drawing.Point(190, 23);
            this.pictureBox_pantsSLVRS.Name = "pictureBox_pantsSLVRS";
            this.pictureBox_pantsSLVRS.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_pantsSLVRS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_pantsSLVRS.TabIndex = 1;
            this.pictureBox_pantsSLVRS.TabStop = false;
            // 
            // pictureBox_pantsAza
            // 
            this.pictureBox_pantsAza.Image = global::Week_09_Take_Home.Properties.Resources.aza_short_pants;
            this.pictureBox_pantsAza.Location = new System.Drawing.Point(3, 23);
            this.pictureBox_pantsAza.Name = "pictureBox_pantsAza";
            this.pictureBox_pantsAza.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_pantsAza.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_pantsAza.TabIndex = 0;
            this.pictureBox_pantsAza.TabStop = false;
            // 
            // panel_Accessories
            // 
            this.panel_Accessories.Controls.Add(this.btn_AddRingDiamond);
            this.panel_Accessories.Controls.Add(this.btn_AddNecklace);
            this.panel_Accessories.Controls.Add(this.btn_AddRing);
            this.panel_Accessories.Controls.Add(this.label_hargaRingDiamond);
            this.panel_Accessories.Controls.Add(this.label_hargaNecklace);
            this.panel_Accessories.Controls.Add(this.label_hargaRing);
            this.panel_Accessories.Controls.Add(this.label_namaRingDiamond);
            this.panel_Accessories.Controls.Add(this.label_namaNecklace);
            this.panel_Accessories.Controls.Add(this.label_namaRing);
            this.panel_Accessories.Controls.Add(this.pictureBox_RingDiamond);
            this.panel_Accessories.Controls.Add(this.pictureBox_necklace);
            this.panel_Accessories.Controls.Add(this.pictureBox_ring);
            this.panel_Accessories.Location = new System.Drawing.Point(11, 32);
            this.panel_Accessories.Name = "panel_Accessories";
            this.panel_Accessories.Size = new System.Drawing.Size(519, 417);
            this.panel_Accessories.TabIndex = 14;
            this.panel_Accessories.Visible = false;
            // 
            // btn_AddRingDiamond
            // 
            this.btn_AddRingDiamond.Location = new System.Drawing.Point(371, 307);
            this.btn_AddRingDiamond.Name = "btn_AddRingDiamond";
            this.btn_AddRingDiamond.Size = new System.Drawing.Size(113, 23);
            this.btn_AddRingDiamond.TabIndex = 11;
            this.btn_AddRingDiamond.Text = "Add to Cart";
            this.btn_AddRingDiamond.UseVisualStyleBackColor = true;
            this.btn_AddRingDiamond.Click += new System.EventHandler(this.btn_AddRingDiamond_Click);
            // 
            // btn_AddNecklace
            // 
            this.btn_AddNecklace.Location = new System.Drawing.Point(190, 307);
            this.btn_AddNecklace.Name = "btn_AddNecklace";
            this.btn_AddNecklace.Size = new System.Drawing.Size(113, 23);
            this.btn_AddNecklace.TabIndex = 10;
            this.btn_AddNecklace.Text = "Add to Cart";
            this.btn_AddNecklace.UseVisualStyleBackColor = true;
            this.btn_AddNecklace.Click += new System.EventHandler(this.btn_AddNecklace_Click);
            // 
            // btn_AddRing
            // 
            this.btn_AddRing.Location = new System.Drawing.Point(6, 307);
            this.btn_AddRing.Name = "btn_AddRing";
            this.btn_AddRing.Size = new System.Drawing.Size(113, 23);
            this.btn_AddRing.TabIndex = 9;
            this.btn_AddRing.Text = "Add to Cart";
            this.btn_AddRing.UseVisualStyleBackColor = true;
            this.btn_AddRing.Click += new System.EventHandler(this.btn_AddRing_Click);
            // 
            // label_hargaRingDiamond
            // 
            this.label_hargaRingDiamond.AutoSize = true;
            this.label_hargaRingDiamond.Location = new System.Drawing.Point(368, 285);
            this.label_hargaRingDiamond.Name = "label_hargaRingDiamond";
            this.label_hargaRingDiamond.Size = new System.Drawing.Size(107, 16);
            this.label_hargaRingDiamond.TabIndex = 8;
            this.label_hargaRingDiamond.Text = "Rp. 1.530.391,00-";
            // 
            // label_hargaNecklace
            // 
            this.label_hargaNecklace.AutoSize = true;
            this.label_hargaNecklace.Location = new System.Drawing.Point(187, 285);
            this.label_hargaNecklace.Name = "label_hargaNecklace";
            this.label_hargaNecklace.Size = new System.Drawing.Size(97, 16);
            this.label_hargaNecklace.TabIndex = 7;
            this.label_hargaNecklace.Text = "Rp. 254.000,00-";
            // 
            // label_hargaRing
            // 
            this.label_hargaRing.AutoSize = true;
            this.label_hargaRing.Location = new System.Drawing.Point(3, 285);
            this.label_hargaRing.Name = "label_hargaRing";
            this.label_hargaRing.Size = new System.Drawing.Size(97, 16);
            this.label_hargaRing.TabIndex = 6;
            this.label_hargaRing.Text = "Rp. 124.000,00-";
            // 
            // label_namaRingDiamond
            // 
            this.label_namaRingDiamond.AutoSize = true;
            this.label_namaRingDiamond.Location = new System.Drawing.Point(368, 259);
            this.label_namaRingDiamond.Name = "label_namaRingDiamond";
            this.label_namaRingDiamond.Size = new System.Drawing.Size(93, 16);
            this.label_namaRingDiamond.TabIndex = 5;
            this.label_namaRingDiamond.Text = "Diamond Ring";
            // 
            // label_namaNecklace
            // 
            this.label_namaNecklace.AutoSize = true;
            this.label_namaNecklace.Location = new System.Drawing.Point(187, 259);
            this.label_namaNecklace.Name = "label_namaNecklace";
            this.label_namaNecklace.Size = new System.Drawing.Size(155, 16);
            this.label_namaNecklace.TabIndex = 4;
            this.label_namaNecklace.Text = "Dolphin Planet Necklace";
            // 
            // label_namaRing
            // 
            this.label_namaRing.AutoSize = true;
            this.label_namaRing.Location = new System.Drawing.Point(3, 259);
            this.label_namaRing.Name = "label_namaRing";
            this.label_namaRing.Size = new System.Drawing.Size(72, 16);
            this.label_namaRing.TabIndex = 3;
            this.label_namaRing.Text = "Silver Ring";
            // 
            // pictureBox_RingDiamond
            // 
            this.pictureBox_RingDiamond.Image = global::Week_09_Take_Home.Properties.Resources.ring;
            this.pictureBox_RingDiamond.Location = new System.Drawing.Point(371, 23);
            this.pictureBox_RingDiamond.Name = "pictureBox_RingDiamond";
            this.pictureBox_RingDiamond.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_RingDiamond.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_RingDiamond.TabIndex = 2;
            this.pictureBox_RingDiamond.TabStop = false;
            // 
            // pictureBox_necklace
            // 
            this.pictureBox_necklace.Image = global::Week_09_Take_Home.Properties.Resources.necklace;
            this.pictureBox_necklace.Location = new System.Drawing.Point(190, 23);
            this.pictureBox_necklace.Name = "pictureBox_necklace";
            this.pictureBox_necklace.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_necklace.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_necklace.TabIndex = 1;
            this.pictureBox_necklace.TabStop = false;
            // 
            // pictureBox_ring
            // 
            this.pictureBox_ring.Image = global::Week_09_Take_Home.Properties.Resources.rings;
            this.pictureBox_ring.Location = new System.Drawing.Point(3, 23);
            this.pictureBox_ring.Name = "pictureBox_ring";
            this.pictureBox_ring.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_ring.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_ring.TabIndex = 0;
            this.pictureBox_ring.TabStop = false;
            // 
            // panel_Shoes
            // 
            this.panel_Shoes.Controls.Add(this.btn_AddShoeLambard);
            this.panel_Shoes.Controls.Add(this.btn_AddShoeYonex);
            this.panel_Shoes.Controls.Add(this.btn_AddShoeAurora);
            this.panel_Shoes.Controls.Add(this.label_hargaShoeLambard);
            this.panel_Shoes.Controls.Add(this.label_hargaShoeYonex);
            this.panel_Shoes.Controls.Add(this.label_hargaShoeAurora);
            this.panel_Shoes.Controls.Add(this.label_namaShoeLambard);
            this.panel_Shoes.Controls.Add(this.label_namaShoeYonex);
            this.panel_Shoes.Controls.Add(this.label_namaShoeAurora);
            this.panel_Shoes.Controls.Add(this.pictureBox_shoeLambard);
            this.panel_Shoes.Controls.Add(this.pictureBox_ShoeYonex);
            this.panel_Shoes.Controls.Add(this.pictureBox_shoeAurora);
            this.panel_Shoes.Location = new System.Drawing.Point(11, 31);
            this.panel_Shoes.Name = "panel_Shoes";
            this.panel_Shoes.Size = new System.Drawing.Size(519, 417);
            this.panel_Shoes.TabIndex = 15;
            this.panel_Shoes.Visible = false;
            // 
            // btn_AddShoeLambard
            // 
            this.btn_AddShoeLambard.Location = new System.Drawing.Point(371, 307);
            this.btn_AddShoeLambard.Name = "btn_AddShoeLambard";
            this.btn_AddShoeLambard.Size = new System.Drawing.Size(113, 23);
            this.btn_AddShoeLambard.TabIndex = 11;
            this.btn_AddShoeLambard.Text = "Add to Cart";
            this.btn_AddShoeLambard.UseVisualStyleBackColor = true;
            this.btn_AddShoeLambard.Click += new System.EventHandler(this.btn_AddShoeLambard_Click);
            // 
            // btn_AddShoeYonex
            // 
            this.btn_AddShoeYonex.Location = new System.Drawing.Point(190, 307);
            this.btn_AddShoeYonex.Name = "btn_AddShoeYonex";
            this.btn_AddShoeYonex.Size = new System.Drawing.Size(113, 23);
            this.btn_AddShoeYonex.TabIndex = 10;
            this.btn_AddShoeYonex.Text = "Add to Cart";
            this.btn_AddShoeYonex.UseVisualStyleBackColor = true;
            this.btn_AddShoeYonex.Click += new System.EventHandler(this.btn_AddShoeYonex_Click);
            // 
            // btn_AddShoeAurora
            // 
            this.btn_AddShoeAurora.Location = new System.Drawing.Point(6, 307);
            this.btn_AddShoeAurora.Name = "btn_AddShoeAurora";
            this.btn_AddShoeAurora.Size = new System.Drawing.Size(113, 23);
            this.btn_AddShoeAurora.TabIndex = 9;
            this.btn_AddShoeAurora.Text = "Add to Cart";
            this.btn_AddShoeAurora.UseVisualStyleBackColor = true;
            this.btn_AddShoeAurora.Click += new System.EventHandler(this.btn_AddShoeAurora_Click);
            // 
            // label_hargaShoeLambard
            // 
            this.label_hargaShoeLambard.AutoSize = true;
            this.label_hargaShoeLambard.Location = new System.Drawing.Point(368, 285);
            this.label_hargaShoeLambard.Name = "label_hargaShoeLambard";
            this.label_hargaShoeLambard.Size = new System.Drawing.Size(97, 16);
            this.label_hargaShoeLambard.TabIndex = 8;
            this.label_hargaShoeLambard.Text = "Rp. 754.000,00-";
            // 
            // label_hargaShoeYonex
            // 
            this.label_hargaShoeYonex.AutoSize = true;
            this.label_hargaShoeYonex.Location = new System.Drawing.Point(187, 285);
            this.label_hargaShoeYonex.Name = "label_hargaShoeYonex";
            this.label_hargaShoeYonex.Size = new System.Drawing.Size(97, 16);
            this.label_hargaShoeYonex.TabIndex = 7;
            this.label_hargaShoeYonex.Text = "Rp. 832.000,00-";
            // 
            // label_hargaShoeAurora
            // 
            this.label_hargaShoeAurora.AutoSize = true;
            this.label_hargaShoeAurora.Location = new System.Drawing.Point(3, 285);
            this.label_hargaShoeAurora.Name = "label_hargaShoeAurora";
            this.label_hargaShoeAurora.Size = new System.Drawing.Size(97, 16);
            this.label_hargaShoeAurora.TabIndex = 6;
            this.label_hargaShoeAurora.Text = "Rp. 999.000,00-";
            // 
            // label_namaShoeLambard
            // 
            this.label_namaShoeLambard.AutoSize = true;
            this.label_namaShoeLambard.Location = new System.Drawing.Point(368, 259);
            this.label_namaShoeLambard.Name = "label_namaShoeLambard";
            this.label_namaShoeLambard.Size = new System.Drawing.Size(130, 16);
            this.label_namaShoeLambard.TabIndex = 5;
            this.label_namaShoeLambard.Text = "Lambard Lightweight";
            // 
            // label_namaShoeYonex
            // 
            this.label_namaShoeYonex.AutoSize = true;
            this.label_namaShoeYonex.Location = new System.Drawing.Point(187, 259);
            this.label_namaShoeYonex.Name = "label_namaShoeYonex";
            this.label_namaShoeYonex.Size = new System.Drawing.Size(166, 16);
            this.label_namaShoeYonex.TabIndex = 4;
            this.label_namaShoeYonex.Text = "YONEX ATLAS Badminton";
            // 
            // label_namaShoeAurora
            // 
            this.label_namaShoeAurora.AutoSize = true;
            this.label_namaShoeAurora.Location = new System.Drawing.Point(3, 259);
            this.label_namaShoeAurora.Name = "label_namaShoeAurora";
            this.label_namaShoeAurora.Size = new System.Drawing.Size(154, 16);
            this.label_namaShoeAurora.TabIndex = 3;
            this.label_namaShoeAurora.Text = "Charged Aurora Training";
            // 
            // pictureBox_shoeLambard
            // 
            this.pictureBox_shoeLambard.Image = global::Week_09_Take_Home.Properties.Resources.Lambard_Lightweight_Sneakers;
            this.pictureBox_shoeLambard.Location = new System.Drawing.Point(371, 23);
            this.pictureBox_shoeLambard.Name = "pictureBox_shoeLambard";
            this.pictureBox_shoeLambard.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_shoeLambard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_shoeLambard.TabIndex = 2;
            this.pictureBox_shoeLambard.TabStop = false;
            // 
            // pictureBox_ShoeYonex
            // 
            this.pictureBox_ShoeYonex.Image = global::Week_09_Take_Home.Properties.Resources.YONEX_ATLAS_Badminton;
            this.pictureBox_ShoeYonex.Location = new System.Drawing.Point(190, 23);
            this.pictureBox_ShoeYonex.Name = "pictureBox_ShoeYonex";
            this.pictureBox_ShoeYonex.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_ShoeYonex.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_ShoeYonex.TabIndex = 1;
            this.pictureBox_ShoeYonex.TabStop = false;
            // 
            // pictureBox_shoeAurora
            // 
            this.pictureBox_shoeAurora.Image = global::Week_09_Take_Home.Properties.Resources.Charged_Aurora_Training_Shoes__999_;
            this.pictureBox_shoeAurora.Location = new System.Drawing.Point(3, 23);
            this.pictureBox_shoeAurora.Name = "pictureBox_shoeAurora";
            this.pictureBox_shoeAurora.Size = new System.Drawing.Size(148, 219);
            this.pictureBox_shoeAurora.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_shoeAurora.TabIndex = 0;
            this.pictureBox_shoeAurora.TabStop = false;
            // 
            // panel_Other
            // 
            this.panel_Other.Controls.Add(this.btn_Upload);
            this.panel_Other.Controls.Add(this.btn_Add);
            this.panel_Other.Controls.Add(this.tBox_ItemPrice);
            this.panel_Other.Controls.Add(this.tBox_ItemName);
            this.panel_Other.Controls.Add(this.label_ItemPrice);
            this.panel_Other.Controls.Add(this.label_ItemName);
            this.panel_Other.Controls.Add(this.pictureBox_UploadedImage);
            this.panel_Other.Controls.Add(this.label_UploadImage);
            this.panel_Other.Location = new System.Drawing.Point(208, 31);
            this.panel_Other.Name = "panel_Other";
            this.panel_Other.Size = new System.Drawing.Size(519, 354);
            this.panel_Other.TabIndex = 16;
            this.panel_Other.Visible = false;
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(143, 38);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(101, 26);
            this.btn_Upload.TabIndex = 7;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.Enabled = false;
            this.btn_Add.Location = new System.Drawing.Point(213, 272);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(101, 26);
            this.btn_Add.TabIndex = 6;
            this.btn_Add.Text = "Add to Cart";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // tBox_ItemPrice
            // 
            this.tBox_ItemPrice.Enabled = false;
            this.tBox_ItemPrice.Location = new System.Drawing.Point(212, 153);
            this.tBox_ItemPrice.Name = "tBox_ItemPrice";
            this.tBox_ItemPrice.Size = new System.Drawing.Size(102, 22);
            this.tBox_ItemPrice.TabIndex = 5;
            this.tBox_ItemPrice.TextChanged += new System.EventHandler(this.tBox_ItemPrice_TextChanged);
            this.tBox_ItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // tBox_ItemName
            // 
            this.tBox_ItemName.Enabled = false;
            this.tBox_ItemName.Location = new System.Drawing.Point(212, 95);
            this.tBox_ItemName.Name = "tBox_ItemName";
            this.tBox_ItemName.Size = new System.Drawing.Size(102, 22);
            this.tBox_ItemName.TabIndex = 4;
            this.tBox_ItemName.TextChanged += new System.EventHandler(this.tBox_ItemName_TextChanged);
            // 
            // label_ItemPrice
            // 
            this.label_ItemPrice.AutoSize = true;
            this.label_ItemPrice.Location = new System.Drawing.Point(209, 134);
            this.label_ItemPrice.Name = "label_ItemPrice";
            this.label_ItemPrice.Size = new System.Drawing.Size(69, 16);
            this.label_ItemPrice.TabIndex = 3;
            this.label_ItemPrice.Text = "Item Price:";
            // 
            // label_ItemName
            // 
            this.label_ItemName.AutoSize = true;
            this.label_ItemName.Location = new System.Drawing.Point(209, 76);
            this.label_ItemName.Name = "label_ItemName";
            this.label_ItemName.Size = new System.Drawing.Size(75, 16);
            this.label_ItemName.TabIndex = 2;
            this.label_ItemName.Text = "Item Name:";
            // 
            // pictureBox_UploadedImage
            // 
            this.pictureBox_UploadedImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_UploadedImage.Location = new System.Drawing.Point(62, 76);
            this.pictureBox_UploadedImage.Name = "pictureBox_UploadedImage";
            this.pictureBox_UploadedImage.Size = new System.Drawing.Size(141, 222);
            this.pictureBox_UploadedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_UploadedImage.TabIndex = 1;
            this.pictureBox_UploadedImage.TabStop = false;
            // 
            // label_UploadImage
            // 
            this.label_UploadImage.AutoSize = true;
            this.label_UploadImage.Location = new System.Drawing.Point(44, 43);
            this.label_UploadImage.Name = "label_UploadImage";
            this.label_UploadImage.Size = new System.Drawing.Size(93, 16);
            this.label_UploadImage.TabIndex = 0;
            this.label_UploadImage.Text = "Upload Image";
            // 
            // for_UNIQME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 474);
            this.Controls.Add(this.panel_Accessories);
            this.Controls.Add(this.panel_LongPants);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_Shoes);
            this.Controls.Add(this.panel_T);
            this.Controls.Add(this.panel_TShirt);
            this.Controls.Add(this.menuStrip_MainMenu);
            this.Controls.Add(this.tBox_Total);
            this.Controls.Add(this.label_Total);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.tBox_SubTotal);
            this.Controls.Add(this.label_SubTotal);
            this.Controls.Add(this.dgv_Nota);
            this.Controls.Add(this.panel_Other);
            this.MainMenuStrip = this.menuStrip_MainMenu;
            this.Name = "for_UNIQME";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.for_UNIQME_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Nota)).EndInit();
            this.menuStrip_MainMenu.ResumeLayout(false);
            this.menuStrip_MainMenu.PerformLayout();
            this.panel_TShirt.ResumeLayout(false);
            this.panel_TShirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shirtHitam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shirtCream)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shirtBiru)).EndInit();
            this.panel_T.ResumeLayout(false);
            this.panel_T.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_THitam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_TCream)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_TBiru)).EndInit();
            this.panel_LongPants.ResumeLayout(false);
            this.panel_LongPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longStretch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longPilgrim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longHeadGear)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_OrangePants)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pantsSLVRS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pantsAza)).EndInit();
            this.panel_Accessories.ResumeLayout(false);
            this.panel_Accessories.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RingDiamond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_necklace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ring)).EndInit();
            this.panel_Shoes.ResumeLayout(false);
            this.panel_Shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shoeLambard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ShoeYonex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_shoeAurora)).EndInit();
            this.panel_Other.ResumeLayout(false);
            this.panel_Other.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UploadedImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgv_Nota;
        private System.Windows.Forms.Label label_SubTotal;
        private System.Windows.Forms.TextBox tBox_SubTotal;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.TextBox tBox_Total;
        private System.Windows.Forms.Label label_Total;
        private System.Windows.Forms.MenuStrip menuStrip_MainMenu;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.Panel panel_TShirt;
        private System.Windows.Forms.Label label_namaShirtHitam;
        private System.Windows.Forms.Label label_namaShirtCream;
        private System.Windows.Forms.Label label_namaShirtBiru;
        private System.Windows.Forms.PictureBox pictureBox_shirtHitam;
        private System.Windows.Forms.PictureBox pictureBox_shirtCream;
        private System.Windows.Forms.PictureBox pictureBox_shirtBiru;
        private System.Windows.Forms.Label label_hargaShirtHitam;
        private System.Windows.Forms.Label label_hargaShirtCream;
        private System.Windows.Forms.Label label_hargaShirtBiru;
        private System.Windows.Forms.Button btn_AddShirtHitam;
        private System.Windows.Forms.Button btn_AddShirtCream;
        private System.Windows.Forms.Button btn_AddShirtBiru;
        private System.Windows.Forms.Panel panel_T;
        private System.Windows.Forms.Button btn_AddTHitam;
        private System.Windows.Forms.Button btn_AddTCream;
        private System.Windows.Forms.Button btn_AddTBiru;
        private System.Windows.Forms.Label label_hargaTHitam;
        private System.Windows.Forms.Label label_hargaTCream;
        private System.Windows.Forms.Label label_hargaTBiru;
        private System.Windows.Forms.Label label_namaTHitam;
        private System.Windows.Forms.Label label_namaTCream;
        private System.Windows.Forms.Label label_namaTBiru;
        private System.Windows.Forms.PictureBox pictureBox_THitam;
        private System.Windows.Forms.PictureBox pictureBox_TCream;
        private System.Windows.Forms.PictureBox pictureBox_TBiru;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_pantsOrange;
        private System.Windows.Forms.Button btn_pantsSLVRS;
        private System.Windows.Forms.Button btn_pantsAZA;
        private System.Windows.Forms.Label label_hargaPantsOrange;
        private System.Windows.Forms.Label label_hargaSLVRSPants;
        private System.Windows.Forms.Label label_hargaAzaPants;
        private System.Windows.Forms.Label label_namaPantsOrange;
        private System.Windows.Forms.Label label_namaPantsSLVRS;
        private System.Windows.Forms.Label label_namaPantsAza;
        private System.Windows.Forms.PictureBox pictureBox_OrangePants;
        private System.Windows.Forms.PictureBox pictureBox_pantsSLVRS;
        private System.Windows.Forms.PictureBox pictureBox_pantsAza;
        private System.Windows.Forms.Panel panel_LongPants;
        private System.Windows.Forms.Button btn_AddLongStretch;
        private System.Windows.Forms.Button btn_AddLongPilgrim;
        private System.Windows.Forms.Button btn_AddLongHeadGear;
        private System.Windows.Forms.Label label_hargaLongStretch;
        private System.Windows.Forms.Label label_hargaLongPilgrim;
        private System.Windows.Forms.Label label_hargaLongHeadGear;
        private System.Windows.Forms.Label label_namaLongStretch;
        private System.Windows.Forms.Label label_namaLongPilgrim;
        private System.Windows.Forms.Label label_namaLongHeadGear;
        private System.Windows.Forms.PictureBox pictureBox_longStretch;
        private System.Windows.Forms.PictureBox pictureBox_longPilgrim;
        private System.Windows.Forms.PictureBox pictureBox_longHeadGear;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.Panel panel_Accessories;
        private System.Windows.Forms.Button btn_AddRingDiamond;
        private System.Windows.Forms.Button btn_AddNecklace;
        private System.Windows.Forms.Button btn_AddRing;
        private System.Windows.Forms.Label label_hargaRingDiamond;
        private System.Windows.Forms.Label label_hargaNecklace;
        private System.Windows.Forms.Label label_hargaRing;
        private System.Windows.Forms.Label label_namaRingDiamond;
        private System.Windows.Forms.Label label_namaNecklace;
        private System.Windows.Forms.Label label_namaRing;
        private System.Windows.Forms.PictureBox pictureBox_RingDiamond;
        private System.Windows.Forms.PictureBox pictureBox_necklace;
        private System.Windows.Forms.PictureBox pictureBox_ring;
        private System.Windows.Forms.Panel panel_Shoes;
        private System.Windows.Forms.Button btn_AddShoeLambard;
        private System.Windows.Forms.Button btn_AddShoeYonex;
        private System.Windows.Forms.Button btn_AddShoeAurora;
        private System.Windows.Forms.Label label_hargaShoeLambard;
        private System.Windows.Forms.Label label_hargaShoeYonex;
        private System.Windows.Forms.Label label_hargaShoeAurora;
        private System.Windows.Forms.Label label_namaShoeLambard;
        private System.Windows.Forms.Label label_namaShoeYonex;
        private System.Windows.Forms.Label label_namaShoeAurora;
        private System.Windows.Forms.PictureBox pictureBox_shoeLambard;
        private System.Windows.Forms.PictureBox pictureBox_ShoeYonex;
        private System.Windows.Forms.PictureBox pictureBox_shoeAurora;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem1;
        private System.Windows.Forms.Panel panel_Other;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.TextBox tBox_ItemPrice;
        private System.Windows.Forms.TextBox tBox_ItemName;
        private System.Windows.Forms.Label label_ItemPrice;
        private System.Windows.Forms.Label label_ItemName;
        private System.Windows.Forms.PictureBox pictureBox_UploadedImage;
        private System.Windows.Forms.Label label_UploadImage;
        private System.Windows.Forms.Button btn_Upload;
    }
}

