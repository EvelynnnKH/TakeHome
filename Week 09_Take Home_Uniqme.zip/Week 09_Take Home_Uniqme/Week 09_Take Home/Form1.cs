﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_09_Take_Home
{
    public partial class for_UNIQME : Form
    {
        public for_UNIQME()
        {
            InitializeComponent();
        }
        List<ItemDetails> carts = new List<ItemDetails>();
        DataTable dt = new DataTable();
        bool tBoxNameFilled = false;
        bool tBoxPriceFilled = false;

        //NOTE, produk beda --> nama sama harga ada yang beda. contoh, "Celana" harga 9000 dengan "Celana" harga 8000 berbeda

        private void for_UNIQME_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");  
            tBox_SubTotal.Enabled = false;
            tBox_Total.Enabled = false;
        }
        private void disableAll()
        {
            panel_pants.Visible = false;
            panel_TShirt.Visible = false;
            panel_T.Visible = false;
            panel_LongPants.Visible = false;
            panel_Accessories.Visible = false;
            panel_Shoes.Visible = false;
            panel_Other.Visible = false;
        }
        private void update()
        {
            dt.Clear();
            List<int> harga = new List<int>();
            CultureInfo culture = new CultureInfo("id-ID");
            double total = 0; 
            for (int i = 0; i < carts.Count; i++)
            {
                string hargaSatuan = String.Format(CultureInfo.GetCultureInfo("id-ID"), "{0:C2}", carts[i].itemPrice);
                string hargaTotalan = String.Format(CultureInfo.GetCultureInfo("id-ID"), "{0:C2}", carts[i].quantity * carts[i].itemPrice);
                dt.Rows.Add(carts[i].itemName, carts[i].quantity, hargaSatuan, hargaTotalan);
                harga.Add(carts[i].quantity * carts[i].itemPrice);
            }
            dgv_Nota.DataSource = dt;
            
            for (int i = 0; i < harga.Count; i++)
            {
                total = total + harga[i];
            }
            tBox_SubTotal.Text = String.Format(CultureInfo.GetCultureInfo("id-ID"), "{0:C2}", total);
            tBox_Total.Text = String.Format(CultureInfo.GetCultureInfo("id-ID"), "{0:C2}", total + (total * 10/100));

        }
        private void AddingSelection(string productName, int productPrice)
        {
            if (checkDoubleOrNo(productName, productPrice) == false)
            {
                carts.Add(new ItemDetails(productName, productPrice, 1));
            }
            else
            {
                foreach (ItemDetails item in carts)
                {
                    if (item.itemName == productName && item.itemPrice == productPrice)
                    {
                        item.quantity++;
                    }
                }
            }
            update();
        }
        private bool checkDoubleOrNo(string product, int price)
        {
            for (int i = 0; i < carts.Count; i++)
            {
                if (carts[i].itemName == product && carts[i].itemPrice == price)
                {
                    return true;
                }
            }
            return false;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_T.Visible = true;
        }
        private void btn_AddShirtCream_Click(object sender, EventArgs e)
        {
            AddingSelection("Shirt Cream", 150000);
        }
        private void btn_AddShirtHitam_Click(object sender, EventArgs e)
        {
            AddingSelection("Shirt Hitam", 130000);
        }
        private void btn_AddShirtBiru_Click(object sender, EventArgs e)
        {
            AddingSelection("Shirt Biru", 150000);
        }
        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_TShirt.Visible = true;
        }
        private void btn_AddTBiru_Click(object sender, EventArgs e)
        {
            AddingSelection("T-Shirt Biru", 140000);
        }
        private void btn_AddTCream_Click(object sender, EventArgs e)
        {
            AddingSelection("T-Shirt Cream", 170000);
        }
        private void btn_AddTHitam_Click(object sender, EventArgs e)
        {
            AddingSelection("T-Shirt Hitam", 150000);
        }
        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_pants.Visible = true;
        }
        private void btn_pantsAZA_Click(object sender, EventArgs e)
        {
            AddingSelection("AZA Short Pants", 90000);
        }
        private void btn_pantsSLVRS_Click(object sender, EventArgs e)
        {
            AddingSelection("SLVRS Short Pants", 79000);
        }
        private void btn_pantsOrange_Click(object sender, EventArgs e)
        {
            AddingSelection("Orange Short Pants", 100000);
        }
        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_LongPants.Visible = true;
        }
        private void btn_AddLongHeadGear_Click(object sender, EventArgs e)
        {
            AddingSelection("Head Gear Pants", 267000);
        }
        private void btn_AddLongPilgrim_Click(object sender, EventArgs e)
        {
            AddingSelection("Pilgrim Long Pants", 365000);
        }
        private void btn_AddLongStretch_Click(object sender, EventArgs e)
        {
            AddingSelection("Stretch Dock Pants", 500000);
        }
        private void btn_AddShoeAurora_Click(object sender, EventArgs e)
        {
            AddingSelection("Charged Aurora Training", 999000);
        }
        private void btn_AddShoeYonex_Click(object sender, EventArgs e)
        {
            AddingSelection("YONEX ATLAS Badminton", 832000);
        }
        private void btn_AddShoeLambard_Click(object sender, EventArgs e)
        {
            AddingSelection("Lambard Lightweight", 754000);
        }
        private void accessoriesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_Accessories.Visible = true;
        }
        private void btn_AddRing_Click(object sender, EventArgs e)
        {
            AddingSelection("Silver Ring", 124000);
        }
        private void btn_AddNecklace_Click(object sender, EventArgs e)
        {
            AddingSelection("Dolphin Planet Necklace", 254000);
        }
        private void btn_AddRingDiamond_Click(object sender, EventArgs e)
        {
            AddingSelection("Diamond Ring", 1530391);
        }
        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_Shoes.Visible = true;
        }
        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            disableAll();
            panel_Other.Visible = true;
        }
        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            string openedFile = ofd.FileName;
            pictureBox_UploadedImage.Image = new Bitmap(openedFile);
            if (openedFile != null)
            {
                tBox_ItemName.Enabled = true;
                tBox_ItemPrice.Enabled = true;
            }
        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (tBox_ItemName.Text != "" && tBox_ItemPrice.Text != "")
            {
                AddingSelection(tBox_ItemName.Text, Convert.ToInt32(tBox_ItemPrice.Text));
                pictureBox_UploadedImage.Image = null;
                tBox_ItemPrice.Text = "";
                tBox_ItemName.Text = "";
                tBoxNameFilled = false;
                tBoxPriceFilled = false;
                tBox_ItemName.Enabled = false;
                tBox_ItemPrice.Enabled = false;
                btn_Add.Enabled = false;
            }
            else
            {
                MessageBox.Show("Please Fill The Product Detail");
            }
        }
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dgv_Nota.CurrentRow;
            if (dgvr.Cells != null)
            {
                int index = dgvr.Index;
                for (int i = 0; i < carts.Count; i++)
                {
                    if (carts[i].itemName == dgvr.Cells[0].Value.ToString())
                    {
                        index = i; break;
                    }
                }
                carts.RemoveAt(index);
                update();
            }
            else
            {
                MessageBox.Show("Please Select The Product You Wanted to Delete");
            }
        }

        private void tBox_ItemName_TextChanged(object sender, EventArgs e)
        {
            if (tBox_ItemName.Text != "")
            {
                tBoxNameFilled = true;
            }
            enableAddToCart();
        }

        private void enableAddToCart()
        {
            if (tBoxNameFilled == true && tBoxPriceFilled == true)
            {
                btn_Add.Enabled = true;
            }
        }
        private void tBox_ItemPrice_TextChanged(object sender, EventArgs e)
        {
            if (tBox_ItemPrice.Text != "")
            {
                tBoxPriceFilled = true;
            }
            enableAddToCart();
        }
    }
}
