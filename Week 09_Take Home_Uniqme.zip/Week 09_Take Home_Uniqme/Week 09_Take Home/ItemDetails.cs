﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_09_Take_Home
{
    internal class ItemDetails
    {
        public string itemName;
        public int itemPrice;
        public int quantity;

        public ItemDetails(string itemName, int itemPrice, int quantity) 
        { 
            this.itemName = itemName;
            this.itemPrice = itemPrice;
            this.quantity = quantity;
        }
    }
}
