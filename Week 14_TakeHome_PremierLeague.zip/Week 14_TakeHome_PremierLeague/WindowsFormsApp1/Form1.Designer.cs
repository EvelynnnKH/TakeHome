﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Team = new System.Windows.Forms.Label();
            this.label_Pemain = new System.Windows.Forms.Label();
            this.label_Minute = new System.Windows.Forms.Label();
            this.label_Type = new System.Windows.Forms.Label();
            this.dgv_dataGrid = new System.Windows.Forms.DataGridView();
            this.cBox_Team = new System.Windows.Forms.ComboBox();
            this.cBox_Pemain = new System.Windows.Forms.ComboBox();
            this.tBox_Minute = new System.Windows.Forms.TextBox();
            this.cBox_Type = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.cBox_TeamAway = new System.Windows.Forms.ComboBox();
            this.cBox_TeamHome = new System.Windows.Forms.ComboBox();
            this.label_Away = new System.Windows.Forms.Label();
            this.label_TeamHome = new System.Windows.Forms.Label();
            this.label_Date = new System.Windows.Forms.Label();
            this.label_MatchID = new System.Windows.Forms.Label();
            this.tBox_MatchID = new System.Windows.Forms.TextBox();
            this.dateTime_DTP = new System.Windows.Forms.DateTimePicker();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // label_Team
            // 
            this.label_Team.AutoSize = true;
            this.label_Team.Location = new System.Drawing.Point(438, 145);
            this.label_Team.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Team.Name = "label_Team";
            this.label_Team.Size = new System.Drawing.Size(49, 16);
            this.label_Team.TabIndex = 0;
            this.label_Team.Text = "Team: ";
            // 
            // label_Pemain
            // 
            this.label_Pemain.AutoSize = true;
            this.label_Pemain.Location = new System.Drawing.Point(430, 175);
            this.label_Pemain.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Pemain.Name = "label_Pemain";
            this.label_Pemain.Size = new System.Drawing.Size(56, 16);
            this.label_Pemain.TabIndex = 1;
            this.label_Pemain.Text = "Pemain:";
            // 
            // label_Minute
            // 
            this.label_Minute.AutoSize = true;
            this.label_Minute.Location = new System.Drawing.Point(435, 208);
            this.label_Minute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Minute.Name = "label_Minute";
            this.label_Minute.Size = new System.Drawing.Size(49, 16);
            this.label_Minute.TabIndex = 2;
            this.label_Minute.Text = "Minute:";
            // 
            // label_Type
            // 
            this.label_Type.AutoSize = true;
            this.label_Type.Location = new System.Drawing.Point(442, 243);
            this.label_Type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Type.Name = "label_Type";
            this.label_Type.Size = new System.Drawing.Size(42, 16);
            this.label_Type.TabIndex = 3;
            this.label_Type.Text = "Type:";
            // 
            // dgv_dataGrid
            // 
            this.dgv_dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_dataGrid.Location = new System.Drawing.Point(60, 115);
            this.dgv_dataGrid.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_dataGrid.Name = "dgv_dataGrid";
            this.dgv_dataGrid.RowHeadersWidth = 82;
            this.dgv_dataGrid.RowTemplate.Height = 33;
            this.dgv_dataGrid.Size = new System.Drawing.Size(353, 253);
            this.dgv_dataGrid.TabIndex = 4;
            // 
            // cBox_Team
            // 
            this.cBox_Team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_Team.FormattingEnabled = true;
            this.cBox_Team.Location = new System.Drawing.Point(494, 143);
            this.cBox_Team.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_Team.Name = "cBox_Team";
            this.cBox_Team.Size = new System.Drawing.Size(197, 24);
            this.cBox_Team.TabIndex = 5;
            this.cBox_Team.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cBox_Pemain
            // 
            this.cBox_Pemain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_Pemain.FormattingEnabled = true;
            this.cBox_Pemain.Location = new System.Drawing.Point(494, 173);
            this.cBox_Pemain.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_Pemain.Name = "cBox_Pemain";
            this.cBox_Pemain.Size = new System.Drawing.Size(197, 24);
            this.cBox_Pemain.TabIndex = 8;
            this.cBox_Pemain.SelectedIndexChanged += new System.EventHandler(this.cBox_Pemain_SelectedIndexChanged);
            // 
            // tBox_Minute
            // 
            this.tBox_Minute.Location = new System.Drawing.Point(494, 206);
            this.tBox_Minute.Margin = new System.Windows.Forms.Padding(2);
            this.tBox_Minute.Name = "tBox_Minute";
            this.tBox_Minute.Size = new System.Drawing.Size(197, 22);
            this.tBox_Minute.TabIndex = 11;
            // 
            // cBox_Type
            // 
            this.cBox_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_Type.FormattingEnabled = true;
            this.cBox_Type.Location = new System.Drawing.Point(494, 240);
            this.cBox_Type.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_Type.Name = "cBox_Type";
            this.cBox_Type.Size = new System.Drawing.Size(197, 24);
            this.cBox_Type.TabIndex = 12;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(486, 279);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(95, 25);
            this.btn_Add.TabIndex = 14;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // cBox_TeamAway
            // 
            this.cBox_TeamAway.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_TeamAway.FormattingEnabled = true;
            this.cBox_TeamAway.Location = new System.Drawing.Point(494, 76);
            this.cBox_TeamAway.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_TeamAway.Name = "cBox_TeamAway";
            this.cBox_TeamAway.Size = new System.Drawing.Size(197, 24);
            this.cBox_TeamAway.TabIndex = 18;
            this.cBox_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cBox_TeamAway_SelectedIndexChanged);
            // 
            // cBox_TeamHome
            // 
            this.cBox_TeamHome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_TeamHome.FormattingEnabled = true;
            this.cBox_TeamHome.Location = new System.Drawing.Point(149, 76);
            this.cBox_TeamHome.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_TeamHome.Name = "cBox_TeamHome";
            this.cBox_TeamHome.Size = new System.Drawing.Size(197, 24);
            this.cBox_TeamHome.TabIndex = 17;
            this.cBox_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cBox_TeamHome_SelectedIndexChanged);
            // 
            // label_Away
            // 
            this.label_Away.AutoSize = true;
            this.label_Away.Location = new System.Drawing.Point(393, 76);
            this.label_Away.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Away.Name = "label_Away";
            this.label_Away.Size = new System.Drawing.Size(82, 16);
            this.label_Away.TabIndex = 16;
            this.label_Away.Text = "Team Away:";
            // 
            // label_TeamHome
            // 
            this.label_TeamHome.AutoSize = true;
            this.label_TeamHome.Location = new System.Drawing.Point(55, 76);
            this.label_TeamHome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_TeamHome.Name = "label_TeamHome";
            this.label_TeamHome.Size = new System.Drawing.Size(86, 16);
            this.label_TeamHome.TabIndex = 15;
            this.label_TeamHome.Text = "Team Home:";
            // 
            // label_Date
            // 
            this.label_Date.AutoSize = true;
            this.label_Date.Location = new System.Drawing.Point(393, 45);
            this.label_Date.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Date.Name = "label_Date";
            this.label_Date.Size = new System.Drawing.Size(78, 16);
            this.label_Date.TabIndex = 20;
            this.label_Date.Text = "Match Date:";
            // 
            // label_MatchID
            // 
            this.label_MatchID.AutoSize = true;
            this.label_MatchID.Location = new System.Drawing.Point(55, 45);
            this.label_MatchID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_MatchID.Name = "label_MatchID";
            this.label_MatchID.Size = new System.Drawing.Size(62, 16);
            this.label_MatchID.TabIndex = 19;
            this.label_MatchID.Text = "Match ID:";
            // 
            // tBox_MatchID
            // 
            this.tBox_MatchID.Enabled = false;
            this.tBox_MatchID.Location = new System.Drawing.Point(149, 44);
            this.tBox_MatchID.Margin = new System.Windows.Forms.Padding(2);
            this.tBox_MatchID.Name = "tBox_MatchID";
            this.tBox_MatchID.Size = new System.Drawing.Size(197, 22);
            this.tBox_MatchID.TabIndex = 21;
            // 
            // dateTime_DTP
            // 
            this.dateTime_DTP.Location = new System.Drawing.Point(494, 45);
            this.dateTime_DTP.Margin = new System.Windows.Forms.Padding(2);
            this.dateTime_DTP.Name = "dateTime_DTP";
            this.dateTime_DTP.Size = new System.Drawing.Size(197, 22);
            this.dateTime_DTP.TabIndex = 22;
            this.dateTime_DTP.ValueChanged += new System.EventHandler(this.dateTime_DTP_ValueChanged);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(596, 279);
            this.btn_Delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(95, 25);
            this.btn_Delete.TabIndex = 23;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(318, 384);
            this.btn_Insert.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(95, 25);
            this.btn_Insert.TabIndex = 24;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 429);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.dateTime_DTP);
            this.Controls.Add(this.tBox_MatchID);
            this.Controls.Add(this.label_Date);
            this.Controls.Add(this.label_MatchID);
            this.Controls.Add(this.cBox_TeamAway);
            this.Controls.Add(this.cBox_TeamHome);
            this.Controls.Add(this.label_Away);
            this.Controls.Add(this.label_TeamHome);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.cBox_Type);
            this.Controls.Add(this.tBox_Minute);
            this.Controls.Add(this.cBox_Pemain);
            this.Controls.Add(this.cBox_Team);
            this.Controls.Add(this.dgv_dataGrid);
            this.Controls.Add(this.label_Type);
            this.Controls.Add(this.label_Minute);
            this.Controls.Add(this.label_Pemain);
            this.Controls.Add(this.label_Team);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Team;
        private System.Windows.Forms.Label label_Pemain;
        private System.Windows.Forms.Label label_Minute;
        private System.Windows.Forms.Label label_Type;
        private System.Windows.Forms.DataGridView dgv_dataGrid;
        private System.Windows.Forms.ComboBox cBox_Team;
        private System.Windows.Forms.ComboBox cBox_Pemain;
        private System.Windows.Forms.TextBox tBox_Minute;
        private System.Windows.Forms.ComboBox cBox_Type;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.ComboBox cBox_TeamAway;
        private System.Windows.Forms.ComboBox cBox_TeamHome;
        private System.Windows.Forms.Label label_Away;
        private System.Windows.Forms.Label label_TeamHome;
        private System.Windows.Forms.Label label_Date;
        private System.Windows.Forms.Label label_MatchID;
        private System.Windows.Forms.TextBox tBox_MatchID;
        private System.Windows.Forms.DateTimePicker dateTime_DTP;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Insert;
    }
}

