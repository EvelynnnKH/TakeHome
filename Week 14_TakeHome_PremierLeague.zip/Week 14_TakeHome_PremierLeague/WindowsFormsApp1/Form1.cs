﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        MySqlConnection connect = new MySqlConnection("server= localhost; uid= root; password= @MYSQLny43v3lynkh; database= premier_league;");
        MySqlCommand command;
        MySqlDataAdapter dataAdapter;
        DataTable dtTeamSekarang;
        DataTable dtNamaPlayer;
        DataTable type = new DataTable();
        DataTable typeWithName = new DataTable();
        DataTable matchDitambah;
        string namaHome;
        string namaAway;
        string idSekarang;

        DataTable teamHome;
        DataTable teamAway;
        DataTable matchIDSekarang;
        DataTable dtNamaSemuaPlayer;
        string query;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connect.Open();
            connect.Close();

            query = $"select type from dmatch group by type;";
            dataAdapter = new MySqlDataAdapter(query, connect);
            dataAdapter.Fill(type);
            typeWithName.Columns.Add("type_id");
            typeWithName.Columns.Add("type_name");
            typeWithName.Rows.Add(type.Rows[0][0].ToString(), "Yellow Card");
            typeWithName.Rows.Add(type.Rows[1][0].ToString(), "Goal");
            typeWithName.Rows.Add(type.Rows[2][0].ToString(), "Own Goal");
            typeWithName.Rows.Add(type.Rows[3][0].ToString(), "Red Card");
            typeWithName.Rows.Add(type.Rows[4][0].ToString(), "Goal Penalty");
            typeWithName.Rows.Add(type.Rows[5][0].ToString(), "Penalty Miss");
            cBox_Type.DataSource = typeWithName;
            cBox_Type.ValueMember = "type_id";
            cBox_Type.DisplayMember = "type_name";
            cBox_Type.SelectedIndex = -1;

            matchDitambah = new DataTable();
            matchDitambah.Columns.Add("Minute");
            matchDitambah.Columns.Add("Team");
            matchDitambah.Columns.Add("Player");
            matchDitambah.Columns.Add("Type");

            dtTeamSekarang = new DataTable();
            dtTeamSekarang.Columns.Add("team_id");
            dtTeamSekarang.Columns.Add("team_name");

            //NGISI TABLE TEAM HOME
            query = "select t.team_name, t.team_id from team t join `match` m on t.team_id = m.team_home group by t.team_name, t.team_id;";
            command = new MySqlCommand(query, connect);
            dataAdapter = new MySqlDataAdapter(command);
            teamHome = new DataTable();
            dataAdapter.Fill(teamHome);
            cBox_TeamHome.DataSource = teamHome;
            cBox_TeamHome.ValueMember = "team_id";
            cBox_TeamHome.DisplayMember = "team_name";
            cBox_TeamHome.SelectedIndex = -1;

            //NGISI TABLE TEAM AWAY
            query = "select t.team_name, t.team_id from team t join `match` m on t.team_id = m.team_away group by t.team_name, t.team_id;";
            command = new MySqlCommand(query, connect);
            dataAdapter = new MySqlDataAdapter(command);
            teamAway = new DataTable();
            dataAdapter.Fill(teamAway);
            cBox_TeamAway.DataSource = teamAway;
            cBox_TeamAway.ValueMember = "team_id";
            cBox_TeamAway.DisplayMember = "team_name";
            cBox_TeamAway.SelectedIndex = -1;

            masukinCboxTeam();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_Team.SelectedValue != null)
            {
                query = $"select player_name, player_id from player where team_id = '{cBox_Team.SelectedValue}';";
                dtNamaPlayer = new DataTable();
                dataAdapter = new MySqlDataAdapter(query, connect);
                dataAdapter.Fill(dtNamaPlayer);
                cBox_Pemain.DataSource = dtNamaPlayer;
                cBox_Pemain.ValueMember = "player_id";
                cBox_Pemain.DisplayMember = "player_name";
                cBox_Pemain.SelectedIndex = -1;
            }
        }

        private void cBox_Pemain_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            string namaTeamTerpilih = "";
            string namaPlayer = "";
            if (cBox_Type.SelectedItem != null && cBox_Team.SelectedItem != null && cBox_Pemain.SelectedItem != null && tBox_Minute.Text != "" && tBox_MatchID.Text != "")
            {
                for (int i = 0; i < cBox_TeamAway.Items.Count; i++)
                {
                    if (cBox_Team.SelectedValue.ToString() == teamAway.Rows[i][1].ToString())
                    {
                        namaTeamTerpilih = teamAway.Rows[i][0].ToString();
                    }
                }
                for (int i = 0; i < cBox_Pemain.Items.Count; i++)
                {
                    if (cBox_Pemain.SelectedValue.ToString() == dtNamaPlayer.Rows[i][1].ToString())
                    {
                        namaPlayer = dtNamaPlayer.Rows[i][0].ToString();
                    }
                }
                matchDitambah.Rows.Add(tBox_Minute.Text, namaTeamTerpilih, namaPlayer, cBox_Type.SelectedValue);
                dgv_dataGrid.DataSource = matchDitambah;
            }
            else
            {
                MessageBox.Show("Please Fill Out All Data!");
            }
        }

        private void cBox_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            Checking();
        }

        private void Checking()
        {
            if (cBox_TeamAway.SelectedItem != null && cBox_TeamHome.SelectedItem != null)
            {
                if (cBox_TeamHome.SelectedValue.ToString() != cBox_TeamAway.SelectedValue.ToString())
                {
                    for (int i = 0; i < cBox_TeamHome.Items.Count; i++)
                    {
                        if (cBox_TeamHome.SelectedValue.ToString() == teamHome.Rows[i][1].ToString().ToString())
                        {
                            namaHome = teamHome.Rows[i][0].ToString();
                            break;
                        }
                    }
                    for (int i = 0; i < cBox_TeamAway.Items.Count; i++)
                    {
                        if (cBox_TeamAway.SelectedValue.ToString() == teamAway.Rows[i][1].ToString())
                        {
                            namaAway = teamAway.Rows[i][0].ToString();
                            break;
                        }
                    }
                    masukinCboxTeam();
                }
                else
                {
                    MessageBox.Show("Cannot Input Team");
                    cBox_TeamHome.SelectedIndex = 0;
                    cBox_TeamAway.SelectedIndex = 0;
                }
            }
        }

        private void cBox_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            Checking();
        }

        private void masukinCboxTeam()
        {
            cBox_Team.ValueMember = "team_id"; //yg mewakili nilainy adalah id nya
            cBox_Team.DisplayMember = "team_name"; //yg ditampilkan
            dtTeamSekarang.Rows.Clear();
            dtTeamSekarang.Rows.Add(cBox_TeamHome.SelectedValue, namaHome);
            dtTeamSekarang.Rows.Add(cBox_TeamAway.SelectedValue, namaAway);
            cBox_Team.SelectedIndex = -1;
            cBox_Team.DataSource = dtTeamSekarang;

            dtNamaSemuaPlayer = new DataTable();
            query = $"select player_name, player_id from player where team_id = '{cBox_TeamHome.SelectedValue}' or team_id = '{cBox_TeamAway.SelectedValue}';";
            dtNamaPlayer = new DataTable();
            dataAdapter = new MySqlDataAdapter(query, connect);
            dataAdapter.Fill(dtNamaSemuaPlayer);
        }

        private void dateTime_DTP_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                DateTime dateMax = new DateTime(2016, 2, 14);
                DateTime dateChoosen = new DateTime(dateTime_DTP.Value.Year, dateTime_DTP.Value.Month, dateTime_DTP.Value.Day);
                int value = DateTime.Compare(dateMax, dateChoosen);
                if (value > 0)
                {
                    MessageBox.Show("Date Invalid");
                    dateTime_DTP.Value = DateTime.Now;
                }
                else
                {
                    cariTeamId();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgrv = dgv_dataGrid.CurrentRow;
            if (dgv_dataGrid.Rows.Count != 0)
            {
                matchDitambah.Rows[dgrv.Index].Delete();
                dgv_dataGrid.Refresh();
            }
            else
            {
                MessageBox.Show("Select a Cell To Delete");
            }
        }

        private void cariTeamId()
        {
            try
            {
                query = "select match_id from `match` order by match_id desc limit 1;";
                command = new MySqlCommand(query, connect);
                dataAdapter = new MySqlDataAdapter(command);
                matchIDSekarang = new DataTable();
                dataAdapter.Fill(matchIDSekarang);
                string id = matchIDSekarang.Rows[0][0].ToString();
                if (id.Substring(0,4) == dateTime_DTP.Value.Year.ToString())
                {
                    int angka = Convert.ToInt32(id.Substring(5, 2));
                    angka += 1;
                    id = id.Substring(0, 4) + string.Format("{0:000}", angka);
                    tBox_MatchID.Text = id;
                    idSekarang = id;
                }
                else
                {
                    tBox_MatchID.Text = dateTime_DTP.Value.Year.ToString() + string.Format("{0:000}", 1);
                    idSekarang = dateTime_DTP.Value.Year.ToString() + string.Format("{0:000}", 1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            if (matchDitambah.Rows.Count != 0)
            {
                int goalHome = 0;
                int goalAway = 0;
                for (int i = 0; i < matchDitambah.Rows.Count; i++)
                {
                    if (matchDitambah.Rows[i][1].ToString() == namaHome)
                    {
                        if (matchDitambah.Rows[i][3].ToString() == "GO")
                        {
                            goalHome++;
                        }
                        if (matchDitambah.Rows[i][3].ToString() == "GP")
                        {
                            goalHome++;
                        }
                        if (matchDitambah.Rows[i][3].ToString() == "PM")
                        {
                            goalAway++;
                        }
                        if (matchDitambah.Rows[i][3].ToString() == "GW")
                        {
                            goalAway++;
                        }
                    }
                    if (matchDitambah.Rows[i][1].ToString() == namaAway)
                    {
                        if (matchDitambah.Rows[i][3].ToString() == "GO")
                        {
                            goalAway++;
                        }
                        if (matchDitambah.Rows[i][3].ToString() == "GP")
                        {
                            goalAway++;
                        }
                        if (matchDitambah.Rows[i][3].ToString() == "PM")
                        {
                            goalHome++;
                        }
                        if (matchDitambah.Rows[i][3].ToString() == "GW")
                        {
                            goalHome++;
                        }
                    }
                }
                query = $"insert into `match` values ('{idSekarang}', '{dateTime_DTP.Value.Year}-{dateTime_DTP.Value.Month}-{dateTime_DTP.Value.Day}', '{cBox_TeamHome.SelectedValue}', '{cBox_TeamAway.SelectedValue}', '{goalHome}', '{goalAway}', 'M002', '0');";
                command = new MySqlCommand(query, connect);
                connect.Open();
                command.ExecuteNonQuery();
                connect.Close();

                masukinKeDmatch();
                cariTeamId();

                matchDitambah.Rows.Clear();
            }
            else
            {
                MessageBox.Show("Please Insert The Data First");
            }
        }

        private void masukinKeDmatch()
        {
            for (int i = 0; i < matchDitambah.Rows.Count; i++)
            {
                string playerId = "";
                if (matchDitambah.Rows[i][1].ToString() == namaHome)
                {
                    for (int j = 0; j < dtNamaSemuaPlayer.Rows.Count; j++)
                    {
                        if (matchDitambah.Rows[i][2].ToString() == dtNamaSemuaPlayer.Rows[j][0].ToString())
                        {
                            playerId = dtNamaSemuaPlayer.Rows[j][1].ToString();
                            break;
                        }
                    }
                    query = $"insert into dmatch values ('{idSekarang}', '{Convert.ToInt32(tBox_Minute.Text)}', '{cBox_TeamHome.SelectedValue}', '{playerId}', '{matchDitambah.Rows[i][3]}','0');";
                    command = new MySqlCommand(query, connect);
                    connect.Open();
                    command.ExecuteNonQuery();
                    connect.Close();
                }

                if (matchDitambah.Rows[i][1].ToString() == namaAway)
                {
                    for (int j = 0; j < dtNamaSemuaPlayer.Rows.Count; j++)
                    {
                        if (matchDitambah.Rows[i][2].ToString() == dtNamaSemuaPlayer.Rows[j][0].ToString())
                        {
                            playerId = dtNamaSemuaPlayer.Rows[j][1].ToString();
                            break;
                        }
                    }
                    query = $"insert into dmatch values ('{idSekarang}', '{Convert.ToInt32(tBox_Minute.Text)}', '{cBox_TeamAway.SelectedValue}', '{playerId}', '{matchDitambah.Rows[i][3]}','0');";
                    command = new MySqlCommand(query, connect);
                    connect.Open();
                    command.ExecuteNonQuery();
                    connect.Close();
                }

            }
            
        }
    }
}
